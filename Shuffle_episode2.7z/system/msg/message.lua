----------------------------------------
-- ADVメッセージ
----------------------------------------
-- メッセージレイヤー／テキスト描画
function mw_text(v)
	if flg.exskip then return end

	autoskip_keystop()

	local p = getTextBlock()	-- text block取得
	if p.lane then
		mw_line(v)

	else
		local i = scr.ip.textcount or 0
		i = i + 1
		scr.ip.textcount = i

		-- message time
		local tm = p.time
		if tm then mw_time(tm) end

		-- text
		if i == 1 then
			estag("init")
			estag{"msgon"}				-- 念の為mw表示
			estag{"sm_text", p}			-- sm
			estag{"mw_voice", p}		-- ボイス設置
			estag{"mw_name", p}			-- 名前表示
			estag{"mw_advtext", p}		-- 本文表示
			estag()
		end
	end
end
----------------------------------------
-- 音声
function mw_voice(p)
	faceview(p)
	if p.vo then
--		voice_stack(p.vo)
--		voice_mainloop()
		sesys_vostack(p.vo)
		sesys_voloop()
	end
end
----------------------------------------
-- 文字速度
function mw_time(time)
	local tm = time
	if tm then	if tm < 0 then tm = 0 elseif tm > 100 then tm = 100 end
	else		tm = getMSpeed() end

	-- main
	tag{"chgmsg", id=(mw_getmsgid("adv"))}
	set_message_speed_tween(tm)
	tag{"/chgmsg"}

	-- sub
	if init.game_sublangview == "on" then
		tag{"chgmsg", id=(mw_getmsgid("sub"))}
		set_message_speed_tween(tm)
		tag{"/chgmsg"}
	end
	scr.mstime = time
end
----------------------------------------
-- 
----------------------------------------
-- 文字色取得
function getMWColor(nm)
	local r = nil
	local m = getGameMode()
	if m == "adv" and init.text_mwcolor == "on" or m == "ui" and init.text_logcolor == "on" then
		local v = csv.voice.name[nm]
		if v then
			r = {"font", color=(v.color), shadowcolor=(v.shadowcolor), outlinecolor=(v.outlinecolor)}
		end
	end
	return r
end
----------------------------------------
-- name
----------------------------------------
-- 名前設置
function mw_name(p)
	local nm = getNameChar(p)
	local tx = getNameText(p)
	if nm and tx then
		-- 文字色
		local cl = getMWColor(nm)
		scr.mwcolor = cl

		-- name
		message_name(tx, cl)
	end
end
----------------------------------------
-- メッセージレイヤー／名前
function message_name(text, cl)
	local textdraw = function(text)
		local cx = init.mwnameframe		-- 名前【】
		if cx and type(cx) == 'table' then text = cx[1]..text..cx[2] end
		tag{"print", data=(text)}
	end

	----------------------------------------
	-- novel
	local nv = getNovelData()
	if nv then
		if text then
			local nm = init.game_novelname
			if nm then
				local ar = getAread()
				local ma = conf.mw_aread or 0
				local cl = ar and ma == 1 and init.novelaread_color	-- novelは既読色がある
				if cl then tag{"font", color=("0"..cl)} end
				textdraw(text)
				if cl then tag{"/font"} end
				if nm == "rt" then tag{"rt"} end
			end
		end

	----------------------------------------
	-- normal
	else
		local id = getMWID("name")
		tag{"chgmsg", id=(mw_getmsgid("name"))}
		tag{"rp"}
		if text then
			-- 名前画像
			if id then
				local nm = init.mwnameimage
				if nm and _G[nm] then _G[nm](id, text) end
				tag{"lyprop", id=(id), visible="1"}
			end
			if cl then tag(cl) end
			textdraw(text)
			if cl then tag{"/font"} end
		else
			if id then tag{"lyprop", id=(id), visible="0"} end
		end
		tag{"/chgmsg"}
	end
end
----------------------------------------
-- メッセージレイヤー／呼び出し
function mw_advtext(tbl)
	message_control(tbl, true)
end
----------------------------------------
-- sm
function sm_text(p)
	-- open
	if p then
		if p.sm and _G.sm_open then sm_open(p.sm) end

	-- close
	elseif _G.sm_close then
		sm_close()
	end
end
----------------------------------------
-- 本文メッセージ制御
----------------------------------------
-- mwid取得
function mw_getmsgid(nm)
	return game.mwid..".mw."..nm
end
----------------------------------------
-- メッセージレイヤー／adv
function chgmsg_adv(flag)
	if flag == "close" then
		e:tag{"/chgmsg"}
	else
		e:tag{"chgmsg", id=(mw_getmsgid("adv"))}
		if not flag then e:tag{"rp"} end
	end
end
----------------------------------------
-- メッセージレイヤー制御
function message_control(tbl, flag)
	estag("init")

	-- 本文 / メイン言語
	local id = mw_getmsgid("adv")
	local ln = get_language(true)
	tag{"chgmsg", id=(id)}
	mw_textloop{ text=(tbl), lang=(ln) }
	if flag then
		flip()
		estag{"eqwait"}
	end

	-- 縦サイズを返す
	local sb = conf.sub_lang or 0
	local r  = nil
	if init.game_sublangview == "on" and sb ~= 0 and tbl[sb] then
		e:tag{"var", system="get_message_layer_height", name="t.tmp.h"}
		r = e:var("t.tmp.h")
	end
	estag{"/chgmsg"}

	-- 本文 / サブ言語
	if r then
		local id = mw_getmsgid("sub")
		estag{"chgmsg", id=(id)}
		estag{"mw_textloop", { text=(tbl), lang=(sb) }}
		if flag then
			estag{"flip"}
			estag{"eqwait"}
		end
		estag{"/chgmsg"}
		estag{"lyprop", id=(id), top=(r)}
	end
	estag()
	return r
end
----------------------------------------
-- 本文解析
function message_adv(tbl, mode, ln)
	message("通知", "古い描画ルーチン")
end
----------------------------------------
-- 本文表示
function mw_textloop(p)
	local mode = p.mode
	local ln   = p.lang
	local v    = p.text[ln]
	if v then
		----------------------------------------
		-- 既読判定
		local m  = getGameMode()
		local ma = conf.mw_aread or 0
		local ar = getAread()
		local cx = not flg.ui and ar and ma == 1 and (getNovelData() and init.novelaread_color or init.textaread_color)
		if cx then tag{"font", color=("0"..cx)}
		elseif m == "adv" and scr.mwcolor then tag(scr.mwcolor) cx = true end

		----------------------------------------
		-- テキスト描画
		local textloop = function(c)
			for i, t in ipairs(v[c]) do
				if type(t) == "table" then
					local s = t[1]
					if mode == "sys" and s == "txkey" then
					elseif tags[s] then tags[s](e, t) else e:tag(t) end		-- [ruby][rt]等の実行
				else
					e:tag{"print", data=(t)}
				end
			end
		end

		----------------------------------------
		-- 全部描く
		if mode == "sys" then
			local m = #v
			for i=1, m do textloop(i) end

		-- 現在の行を描く
		else
			local c = scr.ip.textcount or 1
			textloop(c)
		end
		if cx then tag{"/font"} end
--	else
--		error_message("テキストが見つかりませんでした")
	end
end
----------------------------------------
-- astからtextのみを抽出する
function get_scriptText(block, file)
	local r = ""
	local v = ast.text[block]
	local l = get_language(true)
	if l and v then v = v[l] end
	if v then
		for i, t in ipairs(v) do
			for j, tx in ipairs(t) do
				if type(tx) == "string" then r = r..tx end
			end
		end
	end	
	return r
end
----------------------------------------
-- text再描画
function mw_redraw()
	local ar = getAread()

	-- 読み込み
	local bl = scr.ip.block
	local t  = getTextBlock(no)
	if not t.lane then

		-- 名前
		local nm = getNameText(t)
		if nm then mw_name(t) end

		-- 本文
		message_control(t, true)
	end
end
----------------------------------------
-- 取得
----------------------------------------
-- 名前ベース取得
function getNameChar(p)
	local v = p and p.name
	local r = nil
	if v then r = v.name end
	return r
end
----------------------------------------
-- 名前取得 / 多言語
function getNameText(p)
	local v = p.name
	local r = nil
	if v then
		local ln = get_language(true)
		r = v[ln] or v.name
	end
	return r
end
----------------------------------------
-- 名前取得 / 多言語 / サブ
function getNameSubtext(p)
	local v = p.name
	local r = nil
	if v then
		local ln = conf.sub_lang
		r = v[ln]
	end
	return r
end
----------------------------------------
-- noもしくは現在のtext blockを取得
function getTextBlock(no)
	local n = no or scr.ip.block or 1
	local r = ast.text[n]
	if not r then r = ast.text[#ast.text] end
	return r
end
----------------------------------------
-- テキストのみを返す
function getTextBlockText(no)
	local r = getTextBlock(no)
	return getTextBlockTextRead(r)
end
----------------------------------------
-- テキストのみを返す
function getTextBlockTextRead(r)
	if r then
		-- lang
		local l = { text=1 }
		local s = init.lang
		if s then
			for k, v in pairs(s) do
				l[k] = 1
			end
		end

		-- 抽出
		local z = {}
		for nm, v in pairs(r) do
			if nm == "vo" then
				z.vo = v

			-- 名前はそのままコピー
			elseif nm == "name" then
				z.name = v

			-- 選択肢
			elseif nm == "select" then
				z.select = v

			-- text
			elseif l[nm] then
				local s = ""
				for i, v2 in pairs(v) do
					for i2, tx in pairs(v2) do
						if type(tx) == 'string' then
							s = s..tx
						end
					end
				end
				z[nm] = s
			end
		end
		r = z
	end
	return r
end
----------------------------------------
-- その他制御
----------------------------------------
-- クリック消去
function adv_clsclick()
	----------------------------------------
	-- novel mode
	local s = getNovelData()
	if s then
		local v = getTextBlock()

		-- novel行加算
		scr.novel.no = s.no + 1

		-- 改頁
		if v.pagebreak then
			scr.novel.no = 0
			tag{"rp"}		-- 消去

		-- join
		elseif v.join then

		-- 改行
		else
			rt2()			-- 改行
		end

	----------------------------------------
	-- txnc
	elseif scr.txnc then
		scr.txnc = nil

	----------------------------------------
	-- normal mode
	else
		adv_cls4()
	end
end
----------------------------------------
-- 名前／本文消去
function adv_cls4(flag)
	-- テキストのみ消す
	if flag then
		tag{"chgmsg", id=(mw_getmsgid("name"))}
		tag{"rp"}
		tag{"/chgmsg"}

	-- ADV全消去
	else
		message_name()
		scr.mwcolor = nil		-- text color
	end
	tag{"rp"}		-- 本文消去

	-- sub text
	if init.game_sublangview == "on" then
		local id = mw_getmsgid("sub")
		tag{"chgmsg", id=(id)}
		tag{"rp"}
		tag{"/chgmsg"}
	end
end
----------------------------------------
-- 改行
function rt2()
	tag{"rt", omitblankline="1"}
end
----------------------------------------
-- ノベル改行
function nrt()
	if not flg.ui and scr.novel then
		tag{"rt", omitblankline="1"}
		tag{"rt"}
	end
end
----------------------------------------
-- クリックで文字を消さない
function txnc()
	scr.txnc = true
end
----------------------------------------
-- キー待ち
function txkey()
	if not flg.ui then
		flg.txclick = true
		estag("init")
		estag{"eqwait", { scenario="1" }}
		estag{"txkey_click"}
		estag{"txkey_exit"}
		estag()
	end
end
----------------------------------------
function txkey_click()
	tag{"@"}
end
----------------------------------------
function txkey_exit()
	ResetStack()
	flg.txclick = nil
	mw_text()
end
----------------------------------------
-- 外字
function gaiji(p)
	tag{"font", face=(init.gaiji)}
	tag{"print", data=(p.text)}
	tag{"/font"}
end
----------------------------------------
-- text image
function tximg(p)
	local id = flg.tximgid
	if id then
		local x  = p.x
		local y  = p.y
		local nm = btn.name
		if nm == "blog" then
			local b = lang.font.backlog
			x = b.left
			y = b.top
		end
		lyc2{ id=(id), file=(p.file), x=(x), y=(y)}
	end
end
----------------------------------------
-- font
function exfont(p)
	local sz = p.size
	local co = p.color

	-- 閉じる
	if not sz and not co then
		tag{"/font"}
		scr.fsize = getFontSize()

	-- 
	else
		local n = tn(sz)
		local s = sz and sz:sub(1, 1) == 'f' and tn(sz:sub(2))

		-- 短縮表記を計算
		if s then
			sz = math.floor(getFontSize() * init.fontsize[s] / 100)

		-- 画面サイズ倍率を掛ける
		elseif n then
			local z = game.scale or 1
			if z ~= 1 then sz = math.floor(n * z) end
		end
		tag{"font", size=(sz), color=(co)}
		if sz then scr.fsize = sz end
	end
end
----------------------------------------
--
----------------------------------------
-- font size取得
function getFontSize(name)
	local tbl = { blog="backlog" }
	local bt = btn and btn.name
	local nm = name or bt and tbl[bt] or 'adv'
	local ln = lang and lang.font or {}

	-- advならMW判定
	if nm == "adv" and not ln[nm] then
		local no = scr and scr.mwno or 1
		nm = nm..string.format("%02d", no)
	end
	local sz = ln[nm] or {}
	return sz.size or 20
end
----------------------------------------
