----------------------------------------
-- adv / MW操作
----------------------------------------
-- MW設置
function init_advmw(f)
--	scr.firsthalf = true

	-- MWベース
	setMWImage("bg01")
--	if getMWID("name") then setMWImage("name", nil, 0) end	-- name
	if getMWID("read") then setMWImage("read", nil, 0) end	-- 既読
	if getMWID("auto") then setMWImage("auto", nil, 0) end	-- auto icon
	if getMWID("skip") then setMWImage("skip", nil, 0) end	-- skip icon

	-- name / adv
	setMWFont()
	mw_alpha()
	set_message_speed()

--	glyph_set()		-- glyph設置
	chgmsg_adv()	-- advに変更
	init_adv_btn()	-- ボタン設置
--	setonpush{ key="126", mode="ex", lua="adv_tabletbtn" }

	-- 場所名／bgm名
--	local path = game.path.ui
--	lyc2{ id="1.99.bgx", file=(path.."nt_bg")	, y=100, alpha="0" }
--	lyc2{ id="1.99.bgm", file=(path.."nt_music"), y=100, alpha="0" }

	if not f then
		e:tag{"lyprop", id=(game.mwid), visible="0"}
	end
--	flip()
end
----------------------------------------
-- set font
function setADVFont()

end
----------------------------------------
-- フォント装飾
function fontdeco(name)
	local s  = conf.shadow
	local o  = conf.outline
	local so = o..s
	local f  = conf.font + 1
	local nm = name.."0"..f
	local v  = lang.font[nm]
	local t  = textDecoTable[so]
	local r  = tcopy(v)
	if v and t then
		r[1] = "font"
		r.face		  = init[v.face]
		r.rubyface	  = init[r.ruby]
		r.style		  = t.s
		r.kerning	  = t.k + v.kerning
		r.left		  = t.x + v.left
		r.spacetop	  = t.y + v.spacetop
		r.spacebottom = t.b + v.spacebottom
	end
	return r
end
----------------------------------------
-- set mw image
function setMWImage(name, alpha, visible)
	local t = csv.mw[name]
	if t then
		local px = game.path.ui..t.file
		local id = game.mwid.."."..t.id
		local ix = id..".1"
		lyc2{ id=(ix), file=(px), clip=(t.clip) }

		-- 背景
		local bs = "base"..name
		local b  = csv.mw[bs]
		if b then
			local md = b.clip_a
			local px = game.path.ui..b.file
			local ib = id..".0"
			local ax = math.floor(b.w / 2)
			local ay = math.floor(b.h / 2)
			lyc2{ id=(ib), file=(px), clip=(b.clip), anchorx=(ax), anchory=(ay) }
			if md == "rotate" then
				systween{ id=(ib), rotate="0,360", time=(b.clip_c), ease="none", loop="-1" }
			end
		end
		tag{"lyprop", id=(id), left=(t.x), top=(t.y), alpha=(alpha), visible=(visible) }
	end
end
----------------------------------------
-- mwの透明度
function mw_alpha()
	-- alpha
	local p = repercent(conf.mw_alpha, 255)
	e:tag{"lyprop", id=(getMWID("bg01")), alpha=(p)}

	local id = getMWID("name")
	if id then e:tag{"lyprop", id=(id), alpha=(p)} end
end
----------------------------------------
-- get mw id
function getMWID(name)
	local t = csv.mw[name]
	return t and game.mwid.."."..t.id
end
----------------------------------------
-- mw切り替え
----------------------------------------
-- 切り替え
function mw(p)
	local no = p.no or 1
	scr.mwno = no
	message("通知", no, "番のmwに切り替えます")
	init_adv_btn()
	setMWFont()

	-- novel
	local md = p.mode
	if md == "novel" and getNovel() then
		scr.novel = { no=0 }

	-- 非表示
	else
		scr.novel = nil
		msgcheck("off")
		message_name()
	end
	flip()
end
----------------------------------------
-- fontとglyph
function setMWFont(flag)
	local no = scr.mwno or 1
	local nx = string.format("%02d", no)
	if not flag then
		adv_cls4(true)				-- 文字を消しておく
		setMWImage('bg'..nx)		-- MW書き換え
		setMWImage('name'..nx)		-- MW書き換え
		mw_alpha()					-- alpha再設定
	end

	-- font
	set_textfont(("name"..nx), mw_getmsgid("name"), true)
	set_textfont(("adv"..nx) , mw_getmsgid("adv") , true)
	if init.game_sublangview == "on" then
		set_textfont(("sub"..nx) , mw_getmsgid("sub") , true)
	end

	glyph_set(no)		-- glyph設置
end
----------------------------------------
-- 名前画像
----------------------------------------
-- 文字数で長さを変える
function exnameimage(id, tx)
--[[
	tag{"/font"}
	local tbl = {
		[1280] = { 161, 313 },
		[1920] = { 240, 468 },
	}
	local w  = tbl[game.width]
	local no = scr.mwno or 1
	local v  = csv.mw["name0"..no]
	local ct = #tx / 3
	if ct <= 6 then
		tag{"lyprop", id=(id), clip=(v.clip_a)}
		tag{"font", width=(w[1]), kerning="2"}
	else
		tag{"lyprop", id=(id), clip=(v.clip)}
		tag{"font", width=(w[2]), kerning="2"}
	end
]]
end
----------------------------------------
function lognameimage(nm, tx)
--[[
	tag{"/font"}
	local v  = getBtnInfo(nm)
	local id = v.idx
	local ct = #tx / 3
	if ct <= 6 then
		tag{"lyprop", id=(id), clip="644,320,552,60"}
		tag{"font", width="250", kerning="2"}
	else
		tag{"lyprop", id=(id), clip=(v.clip)}
		tag{"font", width="435", kerning="0"}
	end
]]
end
----------------------------------------
-- ボタン制御
----------------------------------------
-- ボタンを配置
function init_adv_btn()
	local r = select_extend("reload")
	local n = "ui_adv" if init.game_mwchange == "on" then n = n..string.format("%02d", (scr.mwno or 1)) end
	local v = csv[n]
	if v and v[1] and r then
		sys.adv = { dummy=0 }
		local id = game.mwid
--		lydel2(id..".mw.bb")
		csvbtn3("adv", id, v)
		tag{"lyprop", id=(id..".mw.tb"), visible="0"}
		tag{"lyprop", id=(id..".mw.mask"), visible="0"}

		-- mw face
		if v.face01 then
			local c = scr.mwfropen and 255 or 0
			tag{"lyprop", id=(id..".mw.bb"), alpha=(c)}
			scr.mwframe = true
		else
			scr.mwfropen = nil
		end

		-- yesno dialog
		select_yesnoview()

		-- help
--		local ix = getBtnID("help")
--		if ix then tag{"lyprop", id=(ix), visible="0"} end

		local o = game.os
		if game.pa then
			mw_tablet()			-- tablet ui
			mwdock_lock()		-- mw btn lock

			-- scene
			if getExtra() then
				setBtnStat('bt_save', 'c')
				setBtnStat('bt_load', 'c')
				setBtnStat('bt_qsave', 'c')
				setBtnStat('bt_qload', 'c')
--				setBtnStat('bt_selback', 'c')
--				setBtnStat('bt_selnext', 'c')

				setBtnStat('tb_save', 'c')
				setBtnStat('tb_load', 'c')
				setBtnStat('tb_qsave', 'c')
				setBtnStat('tb_qload', 'c')
				setBtnStat('tb_back', 'c')
				setBtnStat('tb_next', 'c')
			end

			-- wasmsync
			local ws = checkWasmsync()
			if ws then
				setBtnStat('bt_selback', 'c')
				setBtnStat('bt_selnext', 'c')
				setBtnStat('tb_back', 'c')
				setBtnStat('tb_next', 'c')
			end
--[[
		elseif o == 'android' then
			mw_tablet()			-- tablet ui

			-- scene
			if getExtra() then
				setBtnStat('tb_save', 'c')
				setBtnStat('tb_load', 'c')
				setBtnStat('tb_qsave', 'c')
				setBtnStat('tb_qload', 'c')
			end
]]
		end
	end
end
----------------------------------------
-- ボタンが押されたときに消してしまう
function advmw_clear(flag)
	local bt = btn.cursor
	if bt and (not flag or flag == "sp" and game.sp) then
		btn_nonactive(bt, true)
		btn.cursor = nil
		mwarea_out()				-- mwbtn lock
	end
end
----------------------------------------
-- 
----------------------------------------
-- sback / 設定行戻す
function mw_autoback()
	local ct = conf.scback
	local mx = #log.stack
	if mx > 1 then
		local bc = mx - ct
		if bc < 1 then bc = 1 end

		message("通知", ct, "行戻します", bc)

		se_ok()
--		ReturnStack()	-- 空のスタックを削除
		quickjumpui(bc)
	end
end
----------------------------------------
-- glyph
----------------------------------------
-- glyph設置	name,x,y,w,h,loop,time,homing
function glyph_set(no)
	chgmsg_adv(true)
	local nm   = "glyph"..string.format("%02d", no)
	local g    = csv.mw[nm]
	local id   = game.mwid.."."..g.id
	local path = game.path.ui
	local max  = g.loop
	local time = g.time

	-- back
	local b = csv.mw.baseglyph
	if b then
		local md = b.clip_a
		local ib = id..".0"
		local px = path..b.file
		local ax = math.floor(b.w / 2)
		local ay = math.floor(b.h / 2)
		lyc2{ id=(ib), file=(px), clip=(b.clip), anchorx=(ax), anchory=(ay) }
		if md == "rotate" then
			systween{ id=(ib), rotate="0,360", time=(b.clip_c), ease="none", loop="-1" }
		end
	end

	-- anime
	local ix = id..".1"
	e:tag{"glyph"}
	e:tag{"anime",		id=(ix), mode="init", file=(path..g.file), clip=("0,0,"..g.w..","..g.h)}
	for i=1, max do
		e:tag{"anime",	id=(ix), mode="add",  file=(path..g.file), clip=((i*g.w)..",0,"..g.w..","..g.h), time=(i*time)}
	end
	e:tag{"anime",		id=(ix), mode="end",  time=(max * time)}

	-- homing
	local h = g.homing or 0
	if h == 0 then
		e:tag{"lyprop",		id=(id), left=(g.x), top=(g.y)}
		e:tag{"glyph",	 layer=(id), homing=(g.homing)}
	else
		e:tag{"glyph",	 layer=(id), homing=(g.homing), left=(g.x), top=(g.y)}
	end
	chgmsg_adv("close")
end
----------------------------------------
-- glyph消去
function glyph_del()
	e:tag{"glyph"}
end
----------------------------------------
--[[
-- glyph check
function glyph_check()
	-- voice
	if scr.voice.glyph then
		glyph_set("glyph_voice")

	-- normal
	else
		glyph_set("glyph_adv")
	end
end
----------------------------------------
-- glyph delete
function glyph_del()
--	message("通知", "glyph delete")
	e:tag{"lydel", id="1.90"}
	e:tag{"glyph"}
	flg.glyph = nil
	scr.adv.glyph = nil
end
----------------------------------------
-- glyph
function glyph_set(name, f)
	local id	= "1.90"
	local time	= init.glyph_time
	local p		= init[name]
	if not f then glyph_del() end
	flg.glyph = {}

--	message("通知", "glyph を設定しました")

	if p and not p[3] then
		-- alpha点滅
		lyc2{  id=(id), file=(p[1]), clip=(p[2])}
		tween{ id=(id), alpha="255,0", time=(time), yoyo="-1"}
	elseif p then
		-- 1    2   3     4     5     6     7
		-- file,max,sizeX,sizeY,clipX,clipY,max2
		local max = p[2] + p[7]
		local cx  = p[5]
		local cy  = p[6]
		for i = 0, max do
			lyc2{ id=(id..'.'..i), file=(p[1]), clip=((cx + i*p[3])..","..cy..","..p[3]..","..p[4]), alpha=0}
		end
		scr.adv.glyph = 0
		tween{ id=(id..".0"), c=0, name=(name), max=(p[2]), max2=(max), time2=(time), alpha="254,255", time=1, delay=(time), handler="calllua", ["function"]="glyph_anime", eq=true }

		flg.glyph.max = max
--[ [
		-- アニメ
		local max = p[2] - 1
		local cx  = p[5]
		local cy  = p[6]

		-- ループ
		e:tag{"anime", id=(id), mode="init", file=(p[1]), clip=(cx..","..cy..","..p[3]..","..p[4])}
		for i = 1, max do
			e:tag{"anime", id=(id), mode="add", file=(p[1]), clip=((cx + i*p[3])..","..cy..","..p[3]..","..p[4]), time=(i*time)}
		end
		e:tag{"anime", id=(id), mode="end", time=(max*time)}
		tween{ id=(id), alpha="254,255", time=(max*time), handler="calllua", ["function"]="glyph_anime", name=(name), eq=true }
] ]
	end

	-- 表示位置
	local p = init.glyph_pos
	e:tag{"lyprop", id=(id), left=(p[1]), top=(p[2])}
	if not f then e:tag{"glyph", layer=(id), homing=(init.glyph_homing)} end
--	e:tag{"glyph", layer=(id), left=(p[1]), top=(p[2]), homing=(init.glyph_homing)}
end
----------------------------------------
function glyph_anime(e, p)
	local c	= tonumber(p.c)
	if scr.mw.msg and flg.glyph and scr.adv.glyph == c then
		local id	= "1.90."
		local time	= tonumber(p.time2)
		local delay	= time

		-- 消す
		tween{ id=(id..c), alpha="1,0", time=1 }

		-- 計算
		c = c + 1
		if c >= 0 + p.max2 then c = 0 + p.max end
		if c >= 0 + p.max  then delay = time * 4 end
		scr.adv.glyph = c
		tween{ id=(id..c), c=(c), name=(p.name), max=(p.max), max2=(p.max2), alpha="254,255", time=1, time2=(time), delay=(delay), handler="calllua", ["function"]="glyph_anime" }

	-- 消しておく
	elseif flg.glyph then
		tween{ id=("1.90."..c), alpha="1,0", time=1 }
	end
end
]]
----------------------------------------
-- mw dock
----------------------------------------
-- mw dock on/offボタンが押された
function mwdock()
	local t = conf.tablet == 1
	local c = conf.dock or 1
	if c == 0 then conf.dock = 1 if t then flg.mwsplock = nil  if game.sp then scr.mwlock = true end end
	else		   conf.dock = 0 if t then flg.mwsplock = true if game.sp then scr.mwlock = nil  end end end
	btn_over(e, { key="bt_lock" })
	flip()
end
----------------------------------------
-- dock lock
function mwdock_mover()
	local c  = conf.dock or 1
	if c == 0 then btn_clip("bt_lock", 'clip_d') end
--	mwhelp_over()
end
----------------------------------------
function mwdock_mout()
	local c  = conf.dock or 1
	if c == 0 then btn_clip("bt_lock", 'clip_c') end
--	mwhelp_out()
end
----------------------------------------
-- volume
function mwdock_vover()
	if conf.fl_master == 0 or conf.master == 0 then btn_clip("bt_mute", 'clip_d') end
end
----------------------------------------
function mwdock_vout()
	if conf.fl_master == 0 or conf.master == 0 then btn_clip("bt_mute", 'clip_c') end
end
----------------------------------------
-- helpマーク
function mwhelp_over()
	local ix = getBtnID("help")
	if ix then tag{"lyprop", id=(ix), visible="1"} end
end
----------------------------------------
function mwhelp_out(e, p)
	local nm = p and p.name
	local bt = btn.cursor
	local ix = getBtnID("help")
	if ix and (not nm or nm == bt) then tag{"lyprop", id=(ix), visible="0"} end
end
----------------------------------------
--
----------------------------------------
-- lock状態 / 初期設定(init_adv_btnから呼ばれる)
function mwdock_lock()
	local gos = game.os
	if gos == "windows" then
		-- dock area
		local ix = getBtnID("dockarea")
		if ix then
			tag{"lyprop", id=(ix), alpha="0", clickablethreshold="128"}
			lyevent{ name="adv", id=(ix), over="mwarea_over", out="mwarea_out"}
			scr.mwlock = true
		end

		-- lock button
		local id = init.mwbtnid
		local lc = init.game_mwdocklock ~= "off"	-- dock初期 : true:表示 / nil:非表示
		local c  = conf.dock or 1					-- dock状態 : 0   :隠す / 1  :固定
		local sl = scr.select and init.game_mwdockselect == "on"
		if c == 1 and lc or sl then
			tag{"lyprop", id=(id..".dc"), visible="1", top="0", left="0"}
--			tag{"lyprop", id=(id..".cl"), visible="1", left="0"}
		else
			tag{"lyprop", id=(id..".dc"), visible="0"}
--			tag{"lyprop", id=(id..".cl"), visible="0"}
			del_uihelp()
			scr.mwhide = true
		end
		scr.mwlock = lc
		set_uihelp(id..".dc.help", "mwhelp")	-- help
		mwdock_mout()							-- dock clip

	-- android / iOS
	elseif game.sp then
		-- lock button
		local id = init.mwbtnid
		local c  = conf.dock or 1
		local t  = flg.mwsplock
		if c == 1 or sel or t then
			tag{"lyprop", id=(id..".dc"), visible="1", top="0"}
--			tag{"lyprop", id=(id..".cl"), visible="1", left="0"}
			scr.mwlock = true
		else
			tag{"lyprop", id=(id..".dc"), visible="0", top="0"}
--			tag{"lyprop", id=(id..".cl"), visible="0"}
			scr.mwlock = nil
			del_uihelp()
		end
		set_uihelp(id..".dc.help", "mwhelp")	-- help
		mwdock_mout()							-- dock clip

		-- wasm
		local ix  = getBtnID("dockarea")
		if ix and gos == "wasm" then
			local wos = game.wasm_os
			if wos == "android" or wos == "ios" then
				tag{"lyprop", id=(ix), visible="0"}
			else
				tag{"lyprop", id=(ix), alpha="0", clickablethreshold="128"}
				lyevent{ name="adv", id=(ix), over="mwarea_over", out="mwarea_out"}
				scr.mwlock = true
			end
		end
	end
end
----------------------------------------
-- mwdock表示アニメ
function mwdock_openanime(time)
	local tm = time or init.mwbtn_fade
	local id = init.mwbtnid..".dc"
--	local i2 = init.mwbtnid..".cl"
	local v  = getBtnInfo("dockarea")
	local x  = v.w
	tag{"lyprop", id=(id), visible="1"}
--	tag{"lyprop", id=(i2), visible="1"}
	systween{ id=(id), y="40,0" , time=(tm) }
	--systween{ id=(id), x=(x..",0"), time=(tm) }
--	systween{ id=(i2), x="150,0", time=(tm) }
end
----------------------------------------
-- mwdock消去アニメ
function mwdock_closeanime(time)
	local tm = time or init.mwbtn_fade
	local id = init.mwbtnid..".dc"
--	local i2 = init.mwbtnid..".cl"
	local v  = getBtnInfo("dockarea")
	local x  = v.w
	--systween{ id=(id), x=("0,"..x), time=(tm) }
	systween{ id=(id), y="0,40" , time=(tm) }
--	systween{ id=(i2), x="0,150", time=(tm) }
	tag{"lyprop", id=(id), visible="0"}
--	tag{"lyprop", id=(i2), visible="0"}
end
----------------------------------------
-- mwdock表示
function mwdock_show()
	if not scr.adv.menu and scr.mwhide then
		scr.mwhide = nil
		mwdock_openanime()
		uitrans(tm)
	end
end
----------------------------------------
-- mwdock消去
function mwdock_hide()
	if not scr.mwhide then
		scr.mwhide = true
		mwdock_closeanime()
		uitrans(tm)
	end
end
----------------------------------------
-- 
function mwarea_over()
	if conf.dock == 0 and not scr.mwlock then
		scr.mwlock = true
--		if not scr.select and not flg.mwmute and not autoskipcheck() then
		if not flg.mwmute and not autoskipcheck() then
			mwdock_show()
		end
	end
end
----------------------------------------
function mwarea_out()
	if conf.dock == 0 and scr.mwlock then
		scr.mwlock = nil

		-- mute
--		if not scr.select and not flg.mwmute then
		if not flg.mwmute then
			mwdock_hide()
		end
	end
end
----------------------------------------
-- 選択肢 mode="sys"
function mwdock_select(flag)
	if conf.dock == 0 and scr.select and game.pa then
		if not flag then
			tag{"lyprop", id=(init.mwbtnid..".dc"), visible="1", top="0", left="0"}
--			tag{"lyprop", id=(init.mwbtnid..".cl"), visible="1", left="0"}
		elseif flag or not scr.mwlock then
			tag{"lyprop", id=(init.mwbtnid..".dc"), visible="0"}
--			tag{"lyprop", id=(init.mwbtnid..".cl"), visible="0"}
			scr.mwlock = nil
		end
	end
end
----------------------------------------
function mwdock_mute()
	if not flg.mwmute then
		flg.mwmute = true

		local tm = init.mwbtn_fade
		if not scr.mwlock then
			local id = init.mwbtnid..".dc"
			tag{"lyprop", id=(id), visible="1"}
			systween{ id=(id), y="40,0", time=(tm) }
		end

		-- slider位置
		sys.adv.dummy = 100 - conf.master
		local y = percent(sys.adv.dummy, 100)
		local v = getBtnInfo("sl_vol")
		local s = repercent(y, v.h - v.p2)
		e:tag{"lyprop", id=(v.idx..".10"), top=(s)}
		tag{"lyprop", id=(getBtnID("sl_vol")), visible="1"}
		uitrans(tm)
	end
end
----------------------------------------
function mwdock_volume(e, p)
	conf.master = 100 - sys.adv.dummy
	volume_master()
end
----------------------------------------
-- 閉じる
function mwdock_muteclose()
	if flg.mwmute then
		flg.mwmute = nil

		local tm = init.mwbtn_fade
		if not scr.mwlock then
			mwdock_closeanime(tm)
		end
		tag{"lyprop", id=(getBtnID("sl_vol")), visible="0"}
		estag("init")
		estag{"uitrans", tm}
		estag{"asyssave"}
		estag()
	end
end
----------------------------------------
-- 
----------------------------------------
function mwmenu_check(nm)
	if nm == "on" then
		menuon()
		mwdock_show()
	elseif nm == "off" then
		menuoff()
		mwdock_hide()
	end
end
----------------------------------------
-- auto / skip
----------------------------------------
-- autoskip開始時に呼ばれる
function autoskip_startimg(name)
	local r = btn and btn.name == "adv"
	if r then
--		message("通知", name, "開始")

		advmw_clear()

		-- glyph削除
		if name == "auto" and init.game_autoglyph == "del" then glyph_del() end

		-- icon
		local idx =  getMWID(name)
		if idx then tag{"lyprop", id=(idx), visible="1"} end

		-- MWボタン
		local id = init.mwbtnid
		if id and game.pa then
			-- tablet ui
			if tabletCheck("ui") then
				tag{"lyprop", id=(init.mwtabid), visible="0"}
			end

			-- mwbtn
			if name == 'auto' then
				local tm = init.mwbtn_fade
				systween{ id=(id), alpha="255,0", time=(tm)}
				mwdock_closeanime(tm)
				estag("init")
--				estag{"eqwait", tm}
				estag{"uitrans", { fade=tm }}
				estag()
			else
				tag{"lyprop", id=(id), visible="0"}
				flip()
			end
		end
		flg.autoskipflag = name
	end
end
----------------------------------------
-- autoskip停止時に呼ばれる
function autoskip_stopimg()
	local r = btn and btn.name == "adv"
	if r then
		local name = flg.autoskipflag
		local tm = init.mwbtn_fade
		local id = init.mwbtnid

		-- glyph設置
		if name == "auto" and init.game_autoglyph == "del" then
			local no = scr.mwno or 1
			glyph_set(no)
		end

		-- tablet ui
		if tabletCheck("ui") then
			tag{"lyprop", id=(init.mwtabid), visible="1"}
		end

		-- icon
		local idx = getMWID(name)
		if idx then tag{"lyprop", id=(idx), visible="0"} end

		if id and game.pa then
			if name == 'auto' then
				local y  = mulpos(60)
				local tm = init.mwbtn_fade
				tag{"lyprop", id=(id), visible="1"}
				if scr.mwlock then
					--systween{ id=(id..".dc"), y=(y..",0"), time=(tm)}
					mwdock_openanime(tm)
				else
				end
--				systween{ id=(id..".cl"), x="64,0", time=(tm)}
				systween{ id=(id), alpha="0,255", time=(tm)}
				flip()
			elseif name == 'skip' then
				tag{"lyprop", id=(id), visible="1"}
				flip()
			end
		end
		flg.tapclear = true		-- 指が離されるまでtap無効化
	end
	flg.autoskipflag = nil
end
----------------------------------------
-- 通知
----------------------------------------
-- qsave/qload通知
function info_qsaveload(name)
	local v = csv.mw[name]
	if v then
		local id = getMWID(name)
		local px = game.path.ui..v.file
		local dr = v.clip_a or "left"
		local ad = v.clip_c or 100
		lyc2{ id=(id..".0"), file=(px), x=(v.x), y=(v.y), clip=(v.clip) }
		if dr == "left" then	tag{"lyprop", id=(id), left=(ad)}
		else					tag{"lyprop", id=(id),  top=(ad)} end

		-- tween
		tag{"lytweendel", id=(id)}
		tag{"tweenset"}
		tag{"lytween", id=(id), param=(dr), from=(ad), to="0", time="500", ease="easeinout_quad"}
		tag{"lytween", id=(id), param=(dr), from="0", to=(ad), time="500", ease="easeinout_quad", delay="2000", delete="1"}
		tag{"/tweenset"}
		flip()
	end
end
----------------------------------------
-- bg / bgm
function notification()
--[[
	local fl = nil

	-- bg
	local nm = flg.notification_bg
	if nm and nm ~= scr.bghead and conf.bgname == 1 then
		local path = game.path.ui.."nt_bg.ipt"
		if e:isFileExists(path) then
			e:include(path)
			flg.notification_bg = nil
			if ipt[nm] then
				scr.bghead = nm
				local id = "1.99.bgx"
				e:tag{"lyprop", id=(id), alpha="255", left="-360", clip=(ipt[nm])}
				e:tag{"lytweendel", id=(id)}
				tween{id=(id), x="-360,0", time="200"}
--				tween{id=(id), x="0,-360", time="200", delay="5000"}
				tween{id=(id), alpha="255,0", time="200", delay="3000"}
				fl = true
			end
		end
	end

	-- bgm
	local nm = flg.notification_bgm
	if nm and conf.bgmname == 1 then
		local path = game.path.ui.."nt_music.ipt"
		if e:isFileExists(path) then
			e:include(path)
			flg.notification_bgm = nil
			if ipt[nm] then
				local id = "1.99.bgm"
				e:tag{"lyprop", id=(id), alpha="255", left="1280", clip=(ipt[nm])}
				e:tag{"lytweendel", id=(id)}
				tween{id=(id), x="1280,920", time="200"}
--				tween{id=(id), x="920,1280", time="200", delay="5000"}
				tween{id=(id), alpha="255,0", time="200", delay="3000"}
				fl = true
			end
		end
	end

	if fl then flip() end
]]
end
----------------------------------------
-- 通知消去
function tags.ntclear() notification_clear() return 1 end
function notification_clear()
	local qs = getMWID("qsave") if qs then tag{"lytweendel", id=(qs)} end	-- qsave
	local ql = getMWID("qload") if ql then tag{"lytweendel", id=(ql)} end	-- qload
--	tag{"lytweendel", id="1.99.bgx"}	-- 背景
--	tag{"lytweendel", id="1.99.bgm"}	-- BGM
--	e:tag{"lyprop", id="1.99.bgx", alpha="0"}
--	e:tag{"lyprop", id="1.99.bgm", alpha="0"}
	notify()
end
----------------------------------------
