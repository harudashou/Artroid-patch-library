----------------------------------------
-- 拡張管理
----------------------------------------
usr = {}
usr.tbl = {}	-- doe=1, bas=1, nan=1, shu=1, lin=1, }
----------------------------------------
e:include('system/extend/user/macro.lua')		-- マクロ再現用
----------------------------------------
-- UIアニメーション
----------------------------------------
function uiopenanime(name)
	local tm = init.ui_fade
	local rule = init["rule_"..name.."on"]
	local sw = {

	----------------------------------------
	-- dialog
	dialog = function()
		tag{"lyprop", id="600.dl", visible="0"}
		estag("init")
		if rule then
			estag{"uitrans", { rule="rule_dialogon", fade="400" } }
		else
			estag{"uitrans"}
		end
		estag{"yesno_active"}
		estag("stop")
	end,

	----------------------------------------
	-- backlog
	blog = function()
		tag{"lyprop", id="500.z", visible="0"}
		estag("init")
		if rule then
			estag{"uitrans", { rule="rule_backlogon", fade="250" } }
		end
		estag{"lyprop", id="500.z", visible="1"}
		estag{"uitrans"}
		estag()
	end,

	----------------------------------------
	-- save / load
	save = function()
		local s = flg.saveanime
		if not s and rule then
			flg.saveanime = true
			local t1 = 150
			local t2 = 150
			local v  = getBtnInfo('logo')
			local y  = (-v.h)..","..(v.y)
			tag{"lyprop", id=(v.idx), visible="0"}
			tag{"lyprop", id="500.z", visible="0"}
			estag("init")
			estag{"systween", { id="500.2", time=(t2 + tm), delay=(t1), alpha="0,255"}}
			estag{"uitrans", { rule="rule_saveon", fade=(t1 + t2) }}
			estag{"systween", { id=(v.idx), y=(y), time=(tm)}}
			estag{"lyprop", id="500.z", visible="1"}
			estag{"lyprop", id=(v.idx), visible="1"}
			estag{"uitrans", tm}
			estag()
		else
			uitrans()
		end
	end,

	----------------------------------------
	-- favo
	favo = function()
		if rule then
			local t1 = 150
			local t2 = 150
			local v  = getBtnInfo('logo')
			local y  = (-v.h)..","..(v.y)
			tag{"lyprop", id=(v.idx), visible="0"}
			tag{"lyprop", id="500.z", visible="0"}
			estag("init")
			estag{"systween", { id="500.2", time=(t2 + tm), delay=(t1), alpha="0,255"}}
			estag{"uitrans", { rule="rule_favoon", fade=(t1 + t2) }}
			estag{"systween", { id=(v.idx), y=(y), time=(tm)}}
			estag{"lyprop", id="500.z", visible="1"}
			estag{"lyprop", id=(v.idx), visible="1"}
			estag{"uitrans", tm}
			estag()
		else
			uitrans()
		end
	end,

	----------------------------------------
	-- config
	conf = function()
		tag{"lyprop", id="500.z", visible="0"}
		estag("init")
		if rule then
			estag{"uitrans", { rule="rule_confon", fade=(tm) }}
		end
		estag{"lyprop", id="500.z", visible="1"}
		estag{"uitrans", tm}
		estag()
	end,

	----------------------------------------
	-- extra
	extra = function()
		local t2 = tm * 2
		local i1 = "500.z"				-- body
		local i2 = getBtnID("bg02")		-- black
		local i3 = "500.sy.1"			-- up
		local i4 = "500.sy.2"			-- dw
		local v1 = getBtnInfo("bg03")	-- up info
		local v2 = getBtnInfo("bg04")	-- dw info
		tag{"lyprop", id=(i1), visible="0"}
		tag{"lyprop", id=(i2), visible="0"}
		tag{"lyprop", id=(i3), top=(-v1.h)}
		tag{"lyprop", id=(i4), top=( v2.h)}
		estag("init")
		if rule then
			estag{"uitrans", { rule="rule_extraon", fade=(t2) }}
			estag{"lyprop", id=(i2), visible="1"}
			estag{"systween", { id=(i3), y=(-v1.h..",0"), time=(t2)}}
			estag{"systween", { id=(i4), y=( v1.h..",0"), time=(t2)}}
			estag{"uitrans", t2}
		else
			estag{"lyprop", id=(i2), visible="1"}
			estag{"systween", { id=(i3), y=(-v1.h..",0"), time=(0)}}
			estag{"systween", { id=(i4), y=( v1.h..",0"), time=(0)}}
		end
		estag{"lyprop", id=(i1), visible="1"}
		estag{"uitrans", tm}
		estag()
	end,
	}
	if sw[name] then sw[name]()
	else uitrans() end
end
----------------------------------------
function uicloseanime(name)
	local tm = init.ui_fade
	local rule = init["rule_"..name.."off"]
	local sw = {

	----------------------------------------
	-- dialog
	dialog = function()
		tag{"lyprop", id="600.dl", visible="0"}
		flip()
		estag("init")
		estag{"lyprop", id="600", visible="0"}
		if rule then
			estag{"uitrans", { rule="rule_dialogoff", fade="400" } }
		else
			estag{"uitrans"}
		end
		estag{"dialog_return"}
		estag()
	end,

	----------------------------------------
	-- backlog
	blog = function()
		tag{"lyprop", id="500.z", visible="0"}
		flip()
		estag("init")
		estag{"blog_reset"}
		if rule then
			estag{"uitrans", { rule="rule_backlogoff", fade="250" } }
		else
			estag{"uitrans"}
		end
		estag()
	end,

	----------------------------------------
	-- save / load
	save = function()
		local r  = scr.savecom == "favo" and "rule_favooff" or "rule_saveoff"
		estag("init")
		if rule then
			local t1 = 150
			local t2 = 150
			local v  = getBtnInfo('logo')
			local y  = (v.y)..","..(-v.h)
				tag{"lyprop", id=(v.idx), visible="0"}
			tag{"lyprop", id="500.z", visible="0"}
			estag{"systween", { id=(v.idx), y=(y), time=(tm)}}
			estag{"systween", { id="500.2", time=(t2 + tm), alpha="255,0"}}
			estag{"uitrans", tm}
			estag{"save_close2"}
			if not getTitle() then estag{"uitrans", { rule=(r), fade=(t1 + t2) }} end
		else
			estag{"save_close2"}
			if not getTitle() then estag{"uitrans"} end
		end
		estag()
	end,

	----------------------------------------
	-- config
	conf = function()
		tag{"lyprop", id="500.z", visible="0"}
		estag("init")
		if rule then
			estag{"uitrans", tm}
			estag{"lyprop", id="500", visible="0"}
			if not getTitle() then estag{"uitrans", { rule="rule_confoff", fade=(tm) }} end
		else
			estag{"lyprop", id="500", visible="0"}
			if not getTitle() then estag{"uitrans"} end
		end
		estag{"conf_reset"}
		estag()
	end,
	}
	if sw[name] then sw[name]()
	else uitrans() end
end
----------------------------------------
--
----------------------------------------
function conf_user_getchar()
	return gscr.conf.charname or "man"
end
----------------------------------------
function conf_user_setparam()
	local p = conf_user_getchar()
	conf.dummy = conf[p]
	conf.fl_dummy = conf["fl_"..p]
end
----------------------------------------
-- 表示変更
function conf_user_charframe()
	local ch = conf_user_getchar()
	local p  = getLangHelp("conf")
	local nm = p[ch]
	if getTrial() and usr.tbl[ch] then nm = "" end
	ui_message("500.z.p01", { 'confch', text=(nm)})
	tag{"lyprop", id="500.z.p01", left="0", top="0"}

	-- slider
	local sl = conf.dummy
	xslider_pin("chsl01", sl)

	-- mute
	local ck = conf.fl_dummy
	local v  = getBtnInfo("chmu01")
	local id = v.idx..".0"
	local cl = ck == 0 and v.clip or v.clip_c
	tag{"lyprop", id=(id), clip=(cl)}
end
----------------------------------------
-- キャラ変更
function conf_user_click(e, p)
	local v  = getBtnInfo(p.btn)
	local ch = conf_user_getchar()
	local p1 = v.p1
	if getTrial() and usr.tbl[p1] then
	elseif ch ~= p1 then
		se_ok()
--		sysvo("sysvo", p1)
		local nm = btn.name
		for i, z in pairs(btn[nm].p) do
			if ch == z.p1 then
				tag{"lyprop", id=("500."..z.id..".0"), clip=(z.clip)}
				break
			end
		end

		-- 保存
		gscr.conf.charname = v.p1
		conf_user_setparam()
		conf_user_charframe()
		flip()
	end
end
----------------------------------------
-- out処理
function conf_user_out(e, p)
	local v  = getBtnInfo(p.name)
	local ch = conf_user_getchar()
	if ch == v.p1 then
		tag{"lyprop", id=(v.idx..".0"), clip=(v.clip_c)}
	end
end
----------------------------------------
-- 
function conf_user_vol(e, p)
	local tb = {
		cla = "ch01", mel = "ch02", kom = "ch03", chi = "ch04",
		mls = "ch06", har = "ch07", iku = "ch08", sut = "ch09", sou = "ch10",
		war = "ch11", tam = "ch12", ryo = "ch13", chc = "ch14", fuy = "ch15",
		doe = "ch16", bas = "ch17", nan = "ch18", shu = "ch19", lin = "ch20",	man = "ch21", fem = "ch22",
	}
	local ch = conf_user_getchar()
	local sl = conf.dummy
	local ck = conf.fl_dummy
	conf[ch] = sl
	conf["fl_"..ch] = ck
	btn.renew = true

	-- mute check
	if p.name == "chmu01" then
		local v  = getBtnInfo(tb[ch])
		local id = "500."..v.id..".30"
		if ck == 0 then
			lyc2{ id=(id), file=(get_uipath().."conf/charmute") }
		else
			lydel2(id)
		end
	end

	-- volume
	sesys_vochar(ch)
end
----------------------------------------
-- sample
function conf_user_test(e, p)
	local ch = conf_user_getchar()
	if getTrial() and usr.tbl[ch] then
	else
		sesys_stop("voice")
		local z = csv.sysse.sysvo.sample[ch]
		if z then
			local m = #z
			local r = e:random() % m + 1

			local px = ":sysvo/"..z[r]..game.soundext
			if isFile(px) then
				sesys_play("voice", px, { ch=(ch) })
			else
				sesys_voplay({ file=(z[r]), ch=(ch) }, true)
			end
		end
	end
end
----------------------------------------
-- muteマスク
function conf_user_muteloop()
	local nm = btn.name
	if nm and btn[nm] then
		-- voice開放
		if not gscr.covo then gscr.covo = {} end
		gscr.covo.man = true
		gscr.covo.fem = true
		local gs = gscr.covo
		local op = init.game_confvoice == "on"

		-- loop
		local ch = conf_user_getchar()
		local px = get_uipath().."conf/charmute"
		for i, v in pairs(btn[nm].p) do
			if v.exec == "conf_user_click" then
				-- mute
				local id = "500."..v.id..".30"
				local p2 = v.p2
				if conf[p2] == 0 then
					lyc2{ id=(id), file=(px) }
				else
					lydel2(id)
				end

				-- open
				local p1 = v.p1
				if op and not gs[p1] or getTrial() and usr.tbl[p1] then
					setBtnStat(v.name, 'd')
				end
			end

			-- active
			if ch == v.p1 then
				tag{"lyprop", id=("500."..v.id..".0"), clip=(v.clip_c)}
			end
		end
		conf_user_charframe()
	end
end
----------------------------------------
function conf_user_sysvo(e, p)
	local v  = getBtnInfo(p.name)
	if v then
		local cm = v.def
		if conf[cm] == 1 then
			local nm = cm:gsub("svo_", "")
			sysvo("sysvo", nm)
		end
	end
end
----------------------------------------
tags["config開放"] = function(e, p)
	local ch = p.ch
	local v  = csv.voice.name or {}
	local nm = v[ch] and v[ch][1]
	if nm then
		if not gscr.covo then gscr.covo = {} end
		if not gscr.covo[nm] then
			gscr.covo[nm] = true
			message("通知", ch, "を開放しました")
			asyssave()
		end
	end
	return 1
end
----------------------------------------
--
----------------------------------------
tags["demo"] = function(e, p)
	local cf = p.auto or 1
	conf.mspeed = p.mspeed or conf.mspeed
	conf.aspeed = p.aspeed or conf.aspeed
	conf.auto   = p.auto or 1
	conf.tabletui = p.tablet or 0
	conf.mw_aread = p.aread  or 0
	adv_auto()
	return 1
end
----------------------------------------
