-- staff roll
----------------------------------------
function staffroll(p)
	autoskip_stop(true)			-- auto/skip保存して停止
	autoskip_ctrl()				-- ctrlskip off
	estag("init")
	estag{"msgoff"}
	estag{"autoskip_ctrl"}		-- ctrlskip off
	estag{"delImageStack"}		-- cache delete
	estag{"exskip_stop"}		-- debugskip停止
	estag{"autoskip_disable"}	-- autoskip disable
	estag{"staffroll2", p}
	estag()
end
----------------------------------------
function staffroll2(p)
	local image_tbl = {
		["リシア"] = "lth",
		["ネリア"] = "nel",
		["きらら"] = "kra",
		["琥珀"] = "koh",
		["リムス"] = "lms",
	}
	local bg_tbl = {
		lth = "bg",
		nel = "bg",
		kra = "bg",
		koh = "bg",
		lms = "bg",
	}
	local text_tbl = {
		lth = "text_lth",
		nel = "text_nel",
		kra = "text_kra",
		koh = "text_koh",
		lms = "text_lms",
	}
	local nm = p.ch or p.route	-- char
	local ch = image_tbl[nm]
	local b  = init.staff_bgm	-- bgm

	-- text
	local ln = get_language(true)
	local bg = bg_tbl[ch]
	local tx = text_tbl[ch]
	if ln ~= "ja" then tx = tx.."_"..ln end

	-- black and white
	local w = game.width
	local h = game.height
	reset_bg()
	lyc2{ id="staff.r.aa", file=(init.black), visible="1"}
	lyc2{ id="staff.r.zz", file=(init.white), visible="1"}
	tag{"lyprop", id="staff", intermediate_render="2", clip=("0,0,"..w..","..h)}

	-- bg
	readImage("staff.r.bg", { path=":staff/", file=bg })
	local max = -ipt.base.h + h
	e:tag{"lyprop", id="staff.r.bg", left=(p.left), top=(max), visible="1"}

	-- save
	stf = { time={}, bgm=(b), text=(tx), ch=(ch), max=(max) }
	if not gscr.staff then gscr.staff = {} end

	message("通知", ch, "エンディング", b)

	-- 既読skip処理
	local path = "system/extend/staff_"..ch..".iet"
--	local path = "system/extend/staff.iet"
	local ar   = om or gscr.staff[ch] or 0
	stf.input  = ar
	if ar == 1 then
		local ky = om and "MWCLICK" or "CANCEL"
--		tag{"setonpush", key="2", file=(path), label="staffroll_exit"}
		stf.key = csv.advkey.list[ky]
	end

	-- 呼び出し
	local tm = om and 1000 or 0
	tag{"var", name="t.time", data=(tm)}
	tag{"call", file=(path), label="staffroll"}
end
----------------------------------------
-- staffroll実行
function staffroll_start(e, p)
	local s  = stf
	local ch = s.ch

	----------------------------------------
	-- sli
	local path = ":bgm/"
	local file = s.bgm
	local sli  = path..file..".ogg.sli"
--	local z = csv.extra_bgm[file]
--	if z then sli  = path..z[2]..".ogg.sli" end

	message("通知", sli)

	-- sliからtimeを読み込む
--	local tbl = opensli(sli)		-- 44.1KHz
	local tbl = opensli(sli, 48)	-- 48KHz
	table.sort(tbl)
	for i, v in ipairs(tbl) do stf.time[i] = v end
	local t = stf.time
	local m = #t
	stf.stop = t[m]
	stf.bgm  = file
	stf.count = 1

	----------------------------------------
	-- scroll終了タイミング
--		if ch == "routea" then stf.sctm = t[3] - t[2]
--	elseif ch == "routec" then stf.sctm = t[3] - t[2] end
	stf.sctmbg = t[4] - t[1]
	stf.sctmpg = t[4] - t[2]

	----------------------------------------
	-- text読み込み
	readImage("staff.r.pg", { path=":staff/", file=(s.text) })
	local v = ipt.base
	local y = game.height
	e:tag{"lyprop", id="staff.r.pg", left=(p.left), top=(y), visible="1"}
	stf.py = y
	stf.ph = -v.h + y
end
----------------------------------------
-- bgm再生
function staffroll_bgm()
	local s = stf
	bgm_play{ file=(s.bgm), loop="0", lock=0 }	-- play
	stf.head = e:now()							-- 時間
end
----------------------------------------
-- スクロール開始
function staffroll_scroll(e, p)
	if not stf then return end

	-- scroll
	local s  = stf
	local tm = p.time or s.sctm or s.stop
	if p.page == "1" then
		tm = s.sctmbg
		tween{ id="staff.r.bg", sys=true, y=(s.max..",0"), time=(tm), ease="none"}
	elseif p.page == "2" then
		tm = s.sctmpg
		tween{ id="staff.r.pg", sys=true, y=(s.py..","..s.ph), time=(tm), ease="none"}
	end
end
----------------------------------------
function staffroll_exit()
	e:tag{"skip", allow="0"}
	e:tag{"exec", command="skip", mode="0"}

	stf.input = 0					-- 入力禁止
	local ch = stf.ch
	e:tag{"lydel", id="1.0"}
	e:tag{"lydel", id="2.0"}
	e:tag{"lydel", id="cache"}
	e:tag{"delonpush", key="2"}		-- 右クリック
	e:tag{"keyconfig", role="1", keys=""}
	reset_bg()
	autoskip_ctrl(true)				-- ctrlskip on
	stf = nil

	-- シーン処理
	if getExtra() then
		setonpush_ui()				-- 念のためキー設定
	else
--		gscr.movie.ed = true		-- 既読フラグ
		gscr.staff[ch] = 1
		gscr.movie[ch] = 1
		estag("init")
		estag{"asyssave"}
		estag{"msg_reset"}
		estag{"setonpush_init"}
		estag{"init_adv_btn"}
		estag{"autoskip_init"}
--		estag{"restart_autoskip"}
		estag()
	end
end
----------------------------------------
-- 無理やり中断させる
function staffroll_reset()
	if stf then
		e:tag{"lydel", id="staff"}
		e:tag{"delonpush", key="2"}		-- 右クリック
		e:tag{"keyconfig", role="1", keys=""}
		stf = nil
	end
end
----------------------------------------
-- trans中断
function staffroll_click()
--	tag{"skip", allow="0"}
	tag{"exec", command="skip", mode="0"}
	staffroll_skip()
end
----------------------------------------
-- trans skip
function staffroll_skip()
	stf.key = nil				-- 入力禁止
	local tm = 3000
	bgm_stop{ time=(tm) }
	estag("init")
	estag{"lyc2", { id="staff.z", file=(init.white) }}
	estag{"uitrans", tm}
	estag{"skip", allow="1"}
	estag{"exec", command="skip", mode="1"}
	estag()
end
----------------------------------------
function tags.edwait(e, p)
	local s = stf
	if s then
		local c = s.count
		local n = e:now() - s.head
		local x = tn(p.time) or 0
		local t = s.time[c] - n + x
		if t < 0 then t = 0 end
		stf.count = c + 1
--		message("time", c, t, n, x)
		eqwait{ time=(t), input=(s.input) }
	end
	return 1
end
----------------------------------------
function tags.edimage()
	local s = stf
	if s then
		local m = #s.buff		-- max
		local c = s.scct		-- カウンタ
		if c <= m then
			local z = s.scwt	-- １枚あたりの時間
			local n = s.scst	-- スクロール開始時間
			local t = (n + c * z) - e:now()		-- 毎回計算して補正をかける

			-- 表示
			estag("init")
			local px = stf.buff[c]
			estag{"lyc2", { id=("staff.r.zz"), file=(px), x=(s.ix), y=(s.iy) }}
			estag{"uitrans", 1000}

			t = t - 2000
			estag{"eqwait", t}

			-- 消去
			estag{"lydel", id=("staff.r.zz")}
			estag{"uitrans", 1000}
			estag()
			stf.scct = c + 1
		end
	end
	return 1
end
----------------------------------------
