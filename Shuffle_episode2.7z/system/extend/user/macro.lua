----------------------------------------
-- 
----------------------------------------
exSelectTable = {
	map = { init="map_init", load="map_load", reload="map_view", reset="map_reset", up="map_keyup", dw="map_keydw" }
}
----------------------------------------
-- autosave
function exautosave()
	if conf.asave == 1 and not flg.autosave then
--		message("通知", "autosave")
		scr.autosave = true
		sv.quicksave()
	end
	flg.autosave = nil
end
----------------------------------------
-- config
----------------------------------------
-- config sample
function config_samplesound(e, nm)
	local bt = type(nm) == "string" and nm or btn.cursor
	if bt then
		local v = getBtnInfo(bt)
		local name = v.p1
		local tbl = {
--			se    = {"se616","se242","se616"},
--			sysse = {"sysse_02"},
--			movie = {""},

			ak	  = {"ak0002007"},
			yz	  = {"yz0012005"},
			mi	  = {"mi0003004"},
			az	  = {"az0006011"},
			ri	  = {"ri0003005"},
			yu	  = {"yu0009005"},
			fem	  = {"sa0024008", "ga0002001"},
			man	  = {"at0001001"},

--			hse   = {"sehl001a","seh001a","seh001b","seh003b"},
--			bgv01 = {"fem_ser_02391","fem_ake_02742","fem_mim_02561","fem_yuk_01915"},
--			bgv02 = {"fem_ser_02377","fem_ake_02728","fem_mim_02547","fem_yuk_01901"},
--			bgv03 = {"fem_ser_02419","fem_ake_02756","fem_mim_02583","fem_yuk_01929"},
		}
		sesys_stop("pause")	-- SE一時停止

		-- se
		if name == "se" then
			local m = #tbl[name]
			local c = e:random() % m + 1
			local f = tbl[name][c]
			se_play{ file=(f), id=9 }

		-- sysse
		elseif name == "sysse" then
			local m = #tbl[name]
			local c = e:random() % m + 1
			local f = tbl[name][c]
			system_se_play{ file=(f) }

		-- movie
		elseif name == "movie" then
			local m = #tbl[name]
			local c = e:random() % m + 1
			local f = tbl[name][c]
			system_se_play{ file=(f) }

		-- hse
		elseif name == "hse" then
			local m = #tbl[name]
			local c = e:random() % m + 1
			local f = tbl[name][c]
			se_play{ file=(f), id=9 }

		-- bgv
		elseif name == "bgv01" or name == "bgv02" or name == "bgv03" then
			local m = #tbl[name]
			local c = flg.samplevo or 0
			c = c + 1 if c > 4 then c = 1 end
			flg.samplevo = c
			local f = tbl[name][c]

			-- volume copy
			local ch = f:sub(5, 7)
			local v = csv.voice[ch]
			local vl = e:var("s.segain.110."..v.id)
			e:tag{"var", name=("s.segain.110.spl"), data=(vl)}		-- loop voice

			-- 再生
			message("通知", ch, f, vl)
			lvo{ ch="spl", file=(f) }

		-- voice
		elseif name == "voice" then
			local m = #tbl[name]
			local c = e:random() % m + 1
			local f = tbl[name][c]
			local s = f:sub(5, 7)
			voice_play({ ch=(s), file=(f) }, true)

		-- voice
		else
			local m = tbl[name] and #tbl[name]
			if m then
				local c = e:random() % m + 1
				local f = tbl[name][c]
				local h = f:sub(1, 2)
				local v = csv.voice
				if (name == "fem" or name == "man") and v[h] then
					name = h
				end
				voice_play({ ch=(name), file=(f) }, true)
			end
		end
	end
end
----------------------------------------
-- map
----------------------------------------
function map_init(p)
	scr.map = {}
	estag("init")
--	estag{"select_autosave"}			-- autosave
	estag{"map_view"}
	estag{"bgm_play", { file="bgm021" }}
	estag{"uitrans"}
	estag{"jump", file="system/script.asb", label="select"}
	estag()
end
----------------------------------------
function map_load()
	estag("init")
	estag{"map_view"}
	estag{"uitrans"}
	estag{"jump", file="system/script.asb", label="select"}
	estag()
end
----------------------------------------
-- 描画
function map_view()
	csvbtn3("map", "1.2", csv.ui_map)
	setonpush_ui(true)

	local path = game.path.ui.."mw/map.ipt"
	if e:isFileExists(path) then
		e:include(path)

		local id = game.mwid
		tag{"lyprop", id=(id), visible="0"}

		-- 位置
		local tr = getTrial() and "trial" or "main"
		local nm = { "ruri", "miko", "yuu_", "mina" }
		local mp = { 0, 0, 0, 0, 0, 0, 0, 0 }
		local tz = {}	-- 進行具合
		for i, v in ipairs(nm) do
			tz[i] = tn(get_eval("f."..v))
			local c  = tz[i] + 1
			local id = getBtnID("mpic0"..i)
			if c <= 0 then
				tag{"lyprop", id=(id), visible="0"}
			else
				local ct = ipt[tr][v][c]
				local ps = ipt[ct]
				tag{"lyprop", id=(id), left=(ps.x), top=(ps.y)}
				mp[ct] = v
			end
		end

		-- いない場所はdisable
		for i, v in ipairs(mp) do
			if v == 0 then
				local nm = "mp0"..i
				setBtnStat(nm, 'c')
			end
		end

		message("map", "瑠莉:",tz[1], "美琴:",tz[2], "悠:",tz[3], "みなと:",tz[4])

		-- カーソル動作書き換え
		setonpush_select()

		-- 保存
--		scr.map.param = tz
		scr.map.map   = mp
	end
	return true
end
----------------------------------------
-- 閉じる
function map_reset()
	bgm_stop{ time="1000" }
	delbtn('map')
	scr.map = nil
end
----------------------------------------
function map_click(e, p)
	local s  = scr.select
	local m  = scr.map
	local bt = btn.cursor or p.btn
	if s and m and bt then
		local v  = getBtnInfo(bt)
		local p1 = tn(v.p1)
		local nm = m.map[p1]
		local ct = get_eval("f."..nm) + 1
		local mx = getTrial() and 3 or 3
		if ct >= mx then ct = -1 end

		se_select()
		local tbl  = { ruri="瑠莉", miko="美琴", yuu_="悠", mina="みなと" }
		local name = tbl[nm]

		message("通知", name, "が選択されました", ct)

		-- バックログの１画面分をクローズ
		set_backlog_next()
		log.stack[#log.stack].select = name

		-- 保存
		set_eval("f."..nm.."="..ct)

		-- 画像消去
		flg.ctrlstop = true		-- ctrlskip無効化
		map_reset()
		estag("init")
--		estag{"init_adv_btn"}		-- mw戻し
		estag{"uitrans", 500}
		estag{"map_exit", { ch=(nm), ct=(ct) }}
		estag()
	end
end
----------------------------------------
function map_exit(p)
	local tbl = {
		trial = {
			ruri = {"瑠莉-01",	 "瑠莉-02",	  "瑠莉-04"},
			miko = {"美琴-01",	 "美琴-02",	  "美琴-04"},
			yuu_ = {"悠-01",	 "悠-02",	  "悠-04"},
			mina = {"みなと-01", "みなと-02", "みなと-04"},
		},
		main = {
			ruri = {"瑠莉-01",	 "瑠莉-02",	  "瑠莉-04"},
			miko = {"美琴-01",	 "美琴-02",	  "美琴-04"},
			yuu_ = {"悠-01",	 "悠-02",	  "悠-04"},
			mina = {"みなと-01", "みなと-02", "みなと-04"},
		},
	}
	local tr = getTrial() and "trial" or "main"
	local ch = p.ch
	local ct = p.ct
	local v  = tbl[tr][ch] if ct == -1 then ct = #v end
	local fl = v[ct]

message("通知", fl, tr)

	ResetStack()		-- stackを空にする
	scr.select = nil
	scr.btnfunc["select|CLICK"] = nil
	scr.p = nil
	delonpush_ui()		-- key戻し
--	glyph_set()			-- glyph戻し

	scr.ip.count = nil	-- カウンタリセット
	set_message_speed()	-- mspeed復帰

	autocache()			-- 自動キャッシュ
	clickEnd(e)			-- click終了処理を通す
	init_adv_btn()		-- mwbtn戻し
	restart_autoskip()	-- autoskip復帰
	setMWFont(true)		-- glyph戻し

	exselback("selsave")	-- 前の選択肢に戻る、の情報をスタック / scr.select削除前に実行
	stack_eval()			-- 更新があったのでスタックしておく

	-- スクリプトの呼び出し
	gotoScript{ file=(fl) }
end
----------------------------------------
function map_keyup() btn_up(e, { name="UP" }) end
----------------------------------------
function map_keydw() btn_down(e, { name="DW" }) end
----------------------------------------
-- 
----------------------------------------
-- 画面上に透明なボタンを追加する
function tags.addbtn(e, p)
	local id = "2"
	local cl = p.clip
	local ur = p.url
	if cl and ur then
		flg.addbtn = { url=(ur) }
		local ax = explode(",", cl)
		lyc2{ id=(id), x=(ax[1]), y=(ax[2]), width=(ax[3]), height=(ax[4]), color="00ff0000"}
		lyevent{ id=(id), key=(1), name="addbtn", over="addbtn_over", out="addbtn_out"}
	else
		lydel2(id)
		flg.addbtn = nil
	end
	flip()
	return 1
end
----------------------------------------
function addbtn_over()
	if flg.addbtn then flg.addbtn.over = true end
end
----------------------------------------
function addbtn_out()
	if flg.addbtn then flg.addbtn.over = nil end
end
----------------------------------------
-- 特殊選択肢
----------------------------------------
tags["押せない選択肢"] = function(e, p)
	-- 初期化
	if not scr.select then
		message("通知", "押せない選択肢を初期化します")
		scr.select = { idx={}, closex="0,1460" }
	end

	local ln = get_language(true)		-- 多言語
	local tx = p[ln] or p.text
	if tx then
		-- textがあれば追加
		table.insert(scr.select, tx)
	else
		-- 実行
		local wa = p.wait or 2000
		autoskip_ctrl()					-- ctrlskip off
		allkeyoff()						-- 入力禁止
		glyph_del()						-- glyphを消す
		estag("init")
		estag{"exskip_stop"}			-- debugskip停止
		estag{"autoskip_stop", true}	-- auto/skip保存して停止
		estag{"skip", allow="0"}		-- slip強制停止
		estag{"msgon"}					-- 念のため[msgon]しておく
		estag{"macroselect_open"}
		estag{"eqwait", wa}
		estag{"macroselect_close"}
		estag{"macroselect_exit"}
		estag()
	end
	return 1
end
----------------------------------------
function macroselect_open()
	local s   = scr.select
	local max = #s

	-- 選択肢ボタン
	local c  = 0
	local t  = csv.mw.select		-- 画像情報
	local id = getMWID("select")	-- id base
	local file = game.path.ui..t.file
	local clip = t.clip
	for i=1, max do
		local v = scr.select[i]
		local ids  = id.."."..(c+1)..".0"
		local idx  = ids..".0"
		local text = v
		scr.select.idx[i] = idx

		-- 画像設置
		lyc2{ id=(idx..'.0'), file=(file), clip=(clip)}
		e:tag{"lyprop", id=(ids), left=(t.x)}

		-- 選択肢に表示するメッセージの生成
		set_textfont("select", idx..".2")
		e:tag{"chgmsg", id=(idx..".2"), layered="1"}
		e:tag{"rp"}
		e:tag{"print", data=(text)}
		e:tag{"/chgmsg"}
		c = c + 1
	end

	-- bg check
	local n = "selectbg"..c
	local b = csv.mw[n]
	if b then lyc2{ id=(id..'.0'), file=(game.path.ui..b.file), clip=(b.clip), x=(b.x), y=(b.y)} end

	-- 座標
	local y = math.ceil(t.h / 2)
	local z = init.select or {}
	if z[c] then
		for i=1, c do
			e:tag{"lyprop", id=(id.."."..i), top=(t.y + math.floor(y * z[c][i]))}
		end
	end

	-- アニメーション
	local b = init.select_animebgin if _G[b] then _G[b]() end
	local z = init.select_animein
	local time	= init.select_time  or 200
	local delay = init.select_delay or 100
	local wait	= time
	for i=1, c do
		local idx = id.."."..i..".0.0"
		local dl  = (i-1)*delay
		if _G[z] then _G[z](idx, time, dl) end
		wait = wait + delay
	end
	flip()
	eqwait(wait)
	for i=1, c do
		local idx = id.."."..i..".0.0"
		eqtag{"lytweendel", id=(idx)}
	end
end
----------------------------------------
function macroselect_close()
	message("通知", "選択肢を終了します")

	-- アニメーション
	local b = init.select_animebgout if _G[b] then _G[b]() end
	local z = init.select_animeout
	local v = scr.select
	local x = v.closex
	local time	= init.select_time  or 200
	local delay = init.select_delay or 100
	local wait	= time
	local max	= #v
	for i=1, max do
		local idx = v.idx[i]
		if idx then
			local dl  = (i-1)*delay
--			if _G[z] then _G[z](idx, time, dl) end
			tween{ id=(idx), x=(x), time=(time), delay=(dl)}
			if i < max then wait = wait + delay end
		end
	end
	flip()
	scr.select.wait = wait
	eqwait(wait)
end
----------------------------------------
function macroselect_exit()
	local id  = getMWID("select")

	-- 選択肢に表示したメッセージの消去
	for i=1, #scr.select do
		local idx = id.."."..i..".0.0.2"
		e:tag{"chgmsg", id=(idx)}
		e:tag{"rp"}
		e:tag{"/chgmsg"}
		lydel2(idx)
	end
	lydel2(id)
	flip()

	-- 事後処理
	exselback("selsave")	-- 前の選択肢に戻る、の情報をスタック / scr.select削除前に実行
	scr.select = nil
	allkeyon()				-- 入力許可
	autoskip_ctrl(true)		-- ctrlskip on
	restart_autoskip()		-- auto/skip再開
end
----------------------------------------
-- 
----------------------------------------
tags["時限選択肢"] = function(e, p)
	-- 初期化
	if not scr.select then
		message("通知", "時限選択肢を初期化します")
		scr.select = { idx={}, closex="0,-1460" }
	end

	local ln = get_language(true)		-- 多言語
	local tx = p[ln] or p.text
	if tx then
		-- textがあれば追加
		table.insert(scr.select, tx)
	else
		-- 実行
		local wa = p.wait or 2000
		scr.select.wait = wa
		autoskip_ctrl()					-- ctrlskip off
		allkeyoff()						-- 入力禁止
		glyph_del()						-- glyphを消す
		estag("init")
		estag{"exskip_stop"}			-- debugskip停止
		estag{"autoskip_stop", true}	-- auto/skip保存して停止
		estag{"skip", allow="0"}		-- skip強制停止
		estag{"msgon"}					-- 念のため[msgon]しておく
		estag{"macroselect_open"}
		estag{"macroselect_event"}
		estag{"eqwait", wa}
		estag{"macroselect_eventdis"}
		estag{"macroselect_close"}
		estag{"macroselect_exit02"}
		estag()
	end
	return 1
end
----------------------------------------
function macroselect_exit02()
	local s = scr.select
	local r = s.success and tn(s.id) or -1
	set_eval('f.s='..r)		-- f.sに結果を保存
	stack_eval()			-- 更新があったのでスタックしておく
	macroselect_exit()
end
----------------------------------------
function macroselect_event()
	local s = scr.select
	local c = #s
	for i=1, c do
		local id = s.idx[i]..'.0'
		tag{"lyevent", id=(id), no=(i), exec=1, handler="calllua", ["function"]="macroselect_click", mode="init", type="click"}
		tag{"lyevent", id=(id), no=(i), exec=1, handler="calllua", ["function"]="macroselect_over" , mode="init", type="rollover"}
		tag{"lyevent", id=(id), no=(i), exec=1, handler="calllua", ["function"]="macroselect_out"  , mode="init", type="rollout"}
	end
	scr.select.now = e:now()
end
----------------------------------------
function macroselect_eventdis()
	local s = scr.select
	local c = #s
	for i=1, c do
		local id = s.idx[i]..'.0'
		tag{"lyevent", id=(id), type="click",    mode="disable"}
		tag{"lyevent", id=(id), type="rollover", mode="disable"}
		tag{"lyevent", id=(id), type="rollout",  mode="disable"}
	end
	tag{"exec", command="skip", mode="0"}
end
----------------------------------------
function macroselect_click(e, p)
	local s = scr.select
	local n = e:now() - s.now
	se_select()
	if n < s.wait then
		scr.select.success = true
	end
	tag{"skip", allow="1"}		-- skip許可
	tag{"exec", command="skip", mode="1"}
end
----------------------------------------
function macroselect_over(e, p)
	if not p.se then se_active() end
	local no = tn(p.no)
	local ix = scr.select.id
	if ix and ix ~= no then select_out(e, { no=(ix) }) end

	local t	 = csv.mw.select		-- 画像情報
	local id = p.id or scr.select.idx[no]..".0"
	tag{"lyprop", id=(id), clip=(t.clip_a)}
	flip()
	scr.select.id = no
end
----------------------------------------
function macroselect_out(e, p)
	local no = tn(p.no)
	if scr.select.id == no then scr.select.id = nil end

	local t  = csv.mw.select		-- 画像情報
	local id = p.id or scr.select.idx[no]..".0"
	tag{"lyprop", id=(id), clip=(t.clip)}
	flip()
end
----------------------------------------
-- 拡張アニメ
----------------------------------------
-- 選択肢背景表示
function select_bganimein()
	local px = game.path.ui
	local id = getMWID("select")	-- id base

	-- 背景
	local b  = csv.mw.selectcl1
	local ix = id..".-1"
	lyc2{  id=(ix), file=(px..b.file), clip=(b.clip), x=(b.x), y=(b.y), anchorx=(b.w), anchory=(b.h), zoom="0"}
	systween{ id=(ix), rotate="0,-360", loop="-1", time="10000", ease="none"}
	tween{ id=(ix), xscale="0,110,100", time="200,200"}
	tween{ id=(ix), yscale="0,110,100", time="200,200"}

	local b  = csv.mw.selectcl2
	local ix = id..".-2"
	lyc2{  id=(ix), file=(px..b.file), clip=(b.clip), x=(b.x), y=(b.y), anchorx=(b.w), anchory=(b.h), zoom="0"}
	systween{ id=(ix), rotate="0,360", loop="-1", time="10000", ease="none"}
	tween{ id=(ix), xscale="0,110,100", time="200,200", delay="50"}
	tween{ id=(ix), yscale="0,110,100", time="200,200", delay="50"}
end
----------------------------------------
-- 選択肢背景消去
function select_bganimeout()
	local px = game.path.ui
	local id = getMWID("select")	-- id base

	-- 背景
	local b  = csv.mw.selectcl1
	local ix = id..".-1"
	tag{"lytweendel", id=(ix)}
	systween{ id=(ix), rotate="0,360", loop="-1", time="1000", ease="none"}
	tween{ id=(ix), xscale="100,110,0", time="200,200", delay="50"}
	tween{ id=(ix), yscale="100,110,0", time="200,200", delay="50"}

	local b  = csv.mw.selectcl2
	local ix = id..".-2"
	tag{"lytweendel", id=(ix)}
	systween{ id=(ix), rotate="0,-360", loop="-1", time="1000", ease="none"}
	tween{ id=(ix), xscale="100,110,0", time="200,200"}
	tween{ id=(ix), yscale="100,110,0", time="200,200"}
end
----------------------------------------
-- 選択肢表示
function select_animein(id, tm, dl)
	local x = "1460,0"
	tween{ id=(id), x=(x), time=(tm), delay=(dl)}
end
----------------------------------------
-- 選択肢消去
function select_animeout(id, tm, dl)
	local x = "0,-1460"
	tween{ id=(id), x=(x), time=(tm), delay=(dl)}
end
----------------------------------------
-- 拡張msgon
function exmsgon(time)
	local no = scr.mwno or 1
	local id = game.mwid
	local i1 = id..".mw.bb"
	local i2 = id..".mw"
	local tb = tabletCheck("ui") and getTabletID()
	local s  = mulpos(init.mw_scroll)
	if no == 1 then
		tag{"lytweendel", id=(i1)}
		tag{"lytweendel", id=(i2)}
		tag{"lyprop", id=(id), top="0"}
		flip()

		-- face
--		local v  = getBtnInfo("face01")
--		tween{ id=(i1), x=(-v.w..",0"), time=(time), delay=(time) }
		flg.exmsgon = true

		-- base
		tween{ id=(i2), y=(s..",0"), time=(time) }

		-- tablet
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			tag{"lytweendel", id=(tb)}
			tween{ id=(tb), alpha=("0,"..al), time=(time), delay=(time) }
		end

		-- wait
		eqwait(time)
--		eqtag{"lytweendel", id=(i1)}
		eqtag{"lytweendel", id=(i2)}
		if tb then eqtag{"lytweendel", id=(tb)} end
	else
		tag{"lyprop", id=(i2), top="0"}
		tween{ id=(id), y=(s..",0"), time=(time) }
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			tag{"lytweendel", id=(tb)}
			tween{ id=(tb), alpha=("0,"..al), time="100", delay=(time) }
		end
		trans{ time=(time) }
	end
end
----------------------------------------
-- 拡張msgoff
function exmsgoff(time, md)
	local no = scr.mwno or 1
	local id = game.mwid
	local tb = tabletCheck("ui") and getTabletID()
	local s  = mulpos(init.mw_scroll)
	if no == 1 then
		local i1 = id..".mw.bb"
		local i2 = id..".mw"
		local tm = time
		tag{"lytweendel", id=(i1)}
		tag{"lytweendel", id=(i2)}

		-- tablet
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			tween{ id=(tb), alpha=(al..",0"), time=(0) }
		end

		-- face
--		local v  = getBtnInfo("face01")
--		tween{ id=(i1), x=("0,"..-v.w), time=(tm) }

		-- base
		tween{ id=(i2), y=("0,"..s), time=(tm)}--, delay=(tm) }

		-- wait
		estag("init")
		estag{"eqwait", tm}
		estag{"lytweendel", id=(i1)}
		estag{"lytweendel", id=(i2)}
		estag{"msgcheck", md}
		estag{"flip"}
		estag()
	else
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			tween{ id=(tb), alpha=(al..",0"), time="0" }
		end
		tween{ id=(id), y=("0,"..s), time=(time) }
		msgcheck(md)
		trans{ time=(time) }
	end
end
----------------------------------------
-- 拡張msgshow
function exmsgshow(time)
	local no = scr.mwno or 1
	local id = game.mwid
	local i1 = id..".mw.bb"
	local i2 = id..".mw"
	local tb = tabletCheck("ui") and getTabletID()
	local s  = mulpos(init.mw_scroll)
	if no == 1 then
		local wx = time
		tag{"lyprop", id=(id), top="0"}
		flip()
		tag{"lytweendel", id=(i1)}
		tag{"lytweendel", id=(i2)}

		-- face
		local dl = 0
		if scr.mwfropen then wx = wx + time dl = time end
		systween{ id=(i1), x=("-368,0"), time=(time), delay=(dl) }

		-- base
		systween{ id=(i2), y=(s..",0"), time=(time) }

		-- tablet
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			systween{ id=(tb), alpha=("0,"..al), time=(time), delay=(time) }
		end

		-- wait
		eqwait(wx)
		eqtag{"lytweendel", id=(i1)}
		eqtag{"lytweendel", id=(i2)}
		if tb then eqtag{"lytweendel", id=(tb)} end
	else
		tag{"lyprop", id=(i2), top="0"}
		systween{ id=(id), y=(s..",0"), time=(time) }
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			systween{ id=(tb), alpha=("0,"..al), time="100", delay=(time) }
		end
		uitrans{ time=(time) }
	end
end
----------------------------------------
-- 拡張msghide
function exmsghide(time)
	local no = scr.mwno or 1
	local id = game.mwid
	local tb = tabletCheck("ui") and getTabletID()
	local s  = mulpos(init.mw_scroll)
	if no == 1 then
		local i1 = id..".mw.bb"
		local i2 = id..".mw"
		local tm = time
		local wx = time
		local dl = 0
		tag{"lytweendel", id=(i1)}
		tag{"lytweendel", id=(i2)}

		-- tablet
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			systween{ id=(tb), alpha=(al..",0"), time=(0) }
		end

		-- face
		local v  = getBtnInfo("face01")
		systween{ id=(i1), x=("0,"..-v.w), time=(tm) }
		if scr.mwfropen then wx = wx + time dl = time end

		-- base
		systween{ id=(i2), y=("0,"..s), time=(tm), delay=(dl) }

		-- wait
		estag("init")
		estag{"eqwait", wx}
--		estag{"msgcheck", md}
--		estag{"flip"}
		estag{"lytweendel", id=(i1)}
		estag{"lytweendel", id=(i2)}
		estag()
	else
		if tb then
			local g  = gscr.tablet
			local al = repercent(g.a, 255)
			systween{ id=(tb), alpha=(al..",0"), time="0" }
		end
		systween{ id=(id), y=("0,"..s), time=(time) }
--		msgcheck(md)
		trans{ time=(time) }
	end
end
----------------------------------------
-- glyph開始時に呼ばれる
function exglyphstart()
	local no = scr.mwno or 1
	local nm = "glyph"..string.format("%02d", no)
	local g  = csv.mw[nm]
	local id = game.mwid.."."..g.id

	eqwait{ scenario="1" }
	tween{ id=(id..".0"), time="100", eq=true, zoom="50,120,100" }
	tween{ id=(id..".1"), time="200", eq=true, alpha="0,255", delay="100" }
end
----------------------------------------
