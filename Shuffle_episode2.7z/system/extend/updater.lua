----------------------------------------
-- アップデータ
----------------------------------------

updater = {}

--canUpdateFlg = false

local dialogstatus = 0

local function getCommand(name)
	local cmd = {
		path = "Updater.exe",
		host = "project-navel.com",
		dir = "/shuffle_ep2/onlineupdate/",
		exec = "SHUFFLE_episode2.exe",
	}
	local datapath = e:var("s.datapath")
	local savapath = e:var("s.savepath")
	local checkcommand = { file = datapath .. "\\" .. cmd.path, option = "/host " .. cmd.host .. " /dir \"" .. cmd.dir .. "\" /crc \"" .. savapath .."\\crc.dat\" /check", block = true }
	local startcommand = { file = datapath .. "\\" .. cmd.path, option = "/host " .. cmd.host .. " /dir \"" .. cmd.dir .. "\" /crc \"" .. savapath .."\\crc.dat\" /exec \"" .. datapath .. "\\" .. cmd.exec .. "\" /force", block = false }

	if name == "check" then
		message("通知", checkcommand)
		return checkcommand
	elseif name == "start" then
		message("通知", startcommand)
		return startcommand
	end
end

--(AD)：Updater.exeが実行可能か
local function canUpdater()
	local datapath = e:var("s.datapath")
	local path = datapath.."\\Updater.exe"
	return os.execute() == 1 and isFile(path)
end

local function runUpdater(command)
	local ret = 0
	local c = command
	c.file = e:convertEncoding{ from="utf8", to="sjis", source=(c.file) }
	c.option = e:convertEncoding{ from="utf8", to="sjis", source=(c.option) }
	ret = e:callShellExecute(c)
	return ret
end

local function check()
	local command = getCommand("check")
	local status = false
	message("通知", "ネットワークアップデートの更新をチェックします")
	if canUpdater() then
		status = runUpdater(command) == 1
	else
		message("通知", "更新の確認に失敗しました")
	end
	canUpdateFlg = status
	return status
end

function updater.init()
	if debug_flag or getTrial() or systemreset then return end

	local canUp = check()
	local firstVer = init.game_ver_windows == "1.00"
	local dialog = function(title, message, response)
		local varname
		if response then
			tag{"var", name="dialog", data=-1}
			varname = "dialog"
		end
		e:tag{"dialog", title=title, message=message, varname=varname}
		e:setEventHandler{ onEnterFrame="updater.vsync" }
	end
	dialogstatus = 0

	if flg.firstboot then
		if firstVer and canUp then
			--(AD)：初期版かつアップデータがある
			dialogstatus = 1
			dialog("データ更新", "ゲームを最新版に更新いたします。ダウンロードしますか？", true)
		elseif firstVer and not canUp then
			--(AD)：初期版だがアップデータが確認できない
			dialogstatus = 2
			dialog("データ更新", "更新を確認できませんでした。アップデータの公開情報など詳細はNavelの公式サイトをご確認ください。", false)
		elseif canUp then
			--(AD)：初回起動でアップデータが確認できる
			dialogstatus = 3
			dialog("データ更新", "ゲームを最新版に更新いたします。ダウンロードしますか？", true)
		end
	end
end

function updater.start(isTitle)
	if canUpdater() then
		if isTitle then
			if not gameexitflag then
				gameexitflag = true		-- 黒フェードを飛ばすためのフラグ
				staffroll_reset()		-- staffroll中断
				tag{"jump", file="system/ui.asb", label="go_updaterexit"}
			end
		else
			tags.updaterstart(e, p)
			e:tag{"exit"}
		end
	else
		e:tag{"dialog", title="確認", message="ネットワークアップデートに失敗しました"}
	end
end

function updater.vsync()
	local dialog = e:var("dialog")
	if dialog == "0" then
		if dialogstatus == 1 or dialogstatus == 3 then
			e:tag{"dialog", title="データ更新", message="タイトル画面のアップデートボタンで最新版への更新が可能です。"}
		end
		e:setEventHandler{ onEnterFrame = "" }
	elseif dialog == "1" then
		e:setEventHandler{ onEnterFrame = "" }
		updater.start()
	end
end

function tags.updaterstart(e, p)
	local command = getCommand("start")
	message("通知", "ネットワークアップデートを開始します")
	runUpdater(command)
	return 1
end
