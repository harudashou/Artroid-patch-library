----------------------------------------
-- steam
----------------------------------------
steam = {}
----------------------------------------
-- アチーブメント登録
tags.achievements = function(e, p)
	if not gscr.steam then gscr.steam = {} end
	local s  = gscr.steam
	local nm = p.name
	if nm and not s[nm] then
		local v  = csv.achievements
		local no = tn(v[nm])

		message("通知", nm, "をアンロックしました", no)

		steam.unlock(no)
		gscr.steam[nm] = true
		asyssave()
	end
	return 1
end
----------------------------------------
function steam.unlock(no)


end
----------------------------------------
-- 言語切替
----------------------------------------
function langch_init()
	local bt = btn and btn.cursor
	if bt then btn_nonactive(bt) end

	-- 初期化
	flg.dlg2 = { bt=bt }
	if btn and btn.name then
		flg.dlg2.ui  = btn.name
		flg.dlg2.glp = btn.group
		flg.dlg2.btn = bt
	end

	-- ドラッグ禁止
	if flg.ui then
		sliderdrag_stat(0)
		flg.dlg2.ret = true		-- uiに戻す
	else
		flg.ui = {}
	end

	-- ボタン描画
	csvbtn3("dlg", "600", csv.ui_lang)		-- dialog

	-- 表示アニメ
	setonpush_ui()
--	tag{"lyprop", id="600.ba", visible="0"}
	tag{"lyprop", id="600.dl", visible="0"}
	estag("init")
	estag{"uitrans", { rule="rule_dialogon", fade="400" } }
	estag{"langch_active"}
	estag{"eqwait"}
	estag("stop")
end
----------------------------------------
function langch_active()
--	tag{"lyprop", id="600.ba", visible="1"}
	tag{"lyprop", id="600.dl", visible="1"}
	uitrans()
end
----------------------------------------
function langch_click(e, p)
	local bt = p.btn
	if bt then
		local v  = getBtnInfo(bt)
		local p1 = v.p1
		conf.language = p1

		-- 画面を閉じる
--		tag{"lyprop", id="600.ba", visible="0"}
		tag{"lyprop", id="600.dl", visible="0"}
		estag("init")
		estag{"uitrans"}
		estag{"lyprop", id="600", visible="0"}
		estag{"uitrans", { rule="rule_dialogoff", fade="400" } }
		estag{"asyssave"}
		estag{"langch_exit"}
		estag()
	end
end
----------------------------------------
function langch_exit()
	local v    = flg.dlg2
	delbtn('dlg')				-- ui消去
	e:tag{"lydel", id="600"}
	btn.name	= v.ui			-- 戻す
	btn.group	= v.glp
	btn.cursor	= v.btn
	flg.dlg2 = nil

	-- configに戻る
	if v.ret then
		sliderdrag_stat(1)		-- ドラッグ許可
		setonpush_ui()
		if game.cs and v.cancel and v.btn and v.ui ~= "adv" then
			btn_active2(v.btn)
		end

	-- その他
	else
		delonpush_ui()
		flg.ui = nil
	end

	-- 戻る
--	tag{"return"}
--	tag{"return"}
--	tag{"jump", file="system/ui.asb", label="return"}
	tag{"reset"}			-- 起動時はリセットしてしまったほうが早い
end
----------------------------------------
-- tag
tags.langselect = function()
	local r = getOSMode()
	local n = sys.langselect
	if r.steam and not n then
		sys.langselect = true
		langch_init()
	end
	return 1
end
----------------------------------------
