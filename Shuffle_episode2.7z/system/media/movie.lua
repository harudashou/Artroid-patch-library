----------------------------------------
-- 動画再生
----------------------------------------
-- 初期化
function movie_init(p)
	scr.movie = p
	exskip_stop()			-- debugskip停止

	-- androidの場合はセーブする
	if game.trueos == "android" then
		e:tag{"var", name="save.systemtable", data=(pluto.persist({}, scr))}
	end

	-- 一旦asbを経由しておく
	e:tag{"call", file="system/script.asb", label="movie_play"}
end
----------------------------------------
-- auto/skip保存して停止
function movie_autoskip()
	if not getTitle() then
		autoskip_stop(true)
		autoskip_disable()
	end
end
----------------------------------------
-- 再生本体
function movie_play()
	local p    = scr.movie
	local file = p.file
	local v    = init.movie[file] or {}		-- movie設定
	local fx   = v.file or file				-- 仮想ファイル

	----------------------------------------
	-- 多言語
	if v.lang then
		local ln = get_language(true)
		local s  = init.langadd[ln]
		if s then fx = fx..s end
	end

	----------------------------------------
	-- 停止キー
	local c  = tn(p.cancel)		-- script設定 0:常に飛ばせない 1:常に飛ばせる 2:初回は飛ばせない
	local sp = v.skip			-- system設定 3:常に飛ばせない 1:常に飛ばせる 2:初回は飛ばせない
	if not c then
		if sp then
			local tbl = { 1, 2, 0 }
			c = tbl[sp]
		else
			c = 1
		end
	end
	if c == 2 and gscr.movie[file] then c = 1 end
	if c == 1 then
		local ky = getKeyString("CANCEL")
		tag{"keyconfig", role="1", keys=(ky)}
	else
		tag{"keyconfig", role="1", keys=""}
	end

	message("通知", file, "を再生します", fx, c)

	----------------------------------------
	-- movie登録
	if not gscr.movie[file] then gscr.movie[file] = true end

	-- bgm登録
	local s = v.bgm
	if s then
		for i, v in ipairs(s) do
			bgm_unlock{ file=(v) }
		end
	end

	----------------------------------------
	-- 背景
	local b = p.bg
	if b then
		image_view({ path=":bg/", file=(b) }, true)
		flip()
	end

	----------------------------------------
	-- volume
	local ans = volume_count("movie", conf.master, (conf.movie or conf.bgm), (v.vol or init.config_moviemax or init.config_bgmmax))
	tag{"var", name="s.videovol", data=(ans)}

	----------------------------------------
	-- 再生
	local path = game.path.movie..fx..game.movieext
	if game.trueos ~= "wasm" then
		tag{"video", file=(path), skip="2"}

	-- wasm再生
	elseif not game.apple then
		tag{"video", file=(path), skip="2"}		-- urlで開く(相対パス)

	-- wasm再生 / apple
	else
		flg.movie_wasmpath = path				-- urlで開く(相対パス)
		movie_wasmset()							-- iOSはeventで再生する
	end
end
----------------------------------------
-- 終了処理
function movie_play_exit()
	e:tag{"var", name="save.systemtable", system="delete"}	-- android用
	e:tag{"keyconfig", role="1", keys=""}
	e:tag{"lydel", id="2"}
	scr.movie = nil

	if not getTitle() then
		autoskip_init()
		restart_autoskip()
	end
end
----------------------------------------
-- wasm用処理 / apple
function movie_wasmset()
	local px = get_uipath().."apple"
	lyc2{ id="wasm", file=(px)}
	e:setEventHandler{ onInputEvent="movie_wasmevent" }
	flip()
	tag{"@"}
end
----------------------------------------
-- 再生してイベント解除
function movie_wasmevent(e, p)
	local no = tn(p.type)
	if flg.movie_wasmpath and (no == 1 or no == 3) then
		tag{"video", file=(flg.movie_wasmpath), skip="2"}
		e:setEventHandler{ onInputEvent="" }
		flg.movie_wasmpath = nil
		lydel2("wasm")
		flip()
	end
end
----------------------------------------
-- 
----------------------------------------
-- ogv
function ogv_play(id, p)
	local file = p.file
	local path = game.path.movie..file
	local loop = p.loop

	-- se
	local sefl = ":se/"..file..game.soundext
	if isFile(sefl) then
		
	end

	-- movie
	tag{"video", id=(id), file=(path..".ogv"), loop=(loop), eq=1}
end
----------------------------------------
