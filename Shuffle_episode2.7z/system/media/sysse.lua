----------------------------------------
-- システムSE
----------------------------------------
-- system se再生
function sysse(name, flag)
	local v  = csv.sysse[name]
	if v then
		local fl = v and v[1] or name
		local id = v.id
		local p  = { id=(id) }
		if flag then p.nosave = true end

		-- 停止
		if name ~= "active" then sesys_stop("sysse") end

		-- 再生
		local path = ":sysse/"..fl..game.soundext
		sesys_play("sysse", path, p)
	end
end
----------------------------------------
-- 完了待機
function sysvowait(p, nm)
	local wa = p["0"] or p.wait
	if wa then
		eqwait{ se=(flg.sysvoid) }
	else
		sysvo(nm)
	end
end
----------------------------------------
-- 短縮関数
----------------------------------------
-- ok
function se_ok()
	if not flg.stopsysse then
		sysse("ok")
	end
	flg.stopsysse = nil
end
----------------------------------------
-- ok
function se_ok2()
	if not flg.closecom then
		sysse("ok")
	end
end
----------------------------------------
 -- アクティブ
function se_active()
	local interval = 60 --(AD)：連続で鳴らさない時間
	local time = se_active_time or 0
	local now = e:now()
	local file = flg.tsysse or "active"
	if not flg.nonactive and (now - time > interval) then
		sysse(file, true)
		se_active_time = now
	end
end
----------------------------------------
function se_cancel()  sysse("cancel") end		-- キャンセル
function se_caution() sysse("caution") end		-- ダイアログ
function se_yes()	  sysse("yes") end			-- dialog yes
function se_no()	  sysse("no") end			-- dialog no
function se_decide()  sysse("decide") end		-- 決定
function se_select()  sysse("select") end		-- 選択肢決定
function se_none()	  sysse("none") end			-- 無効
function se_menu()	  sysse("menu") end			-- menu
function se_logo()	  sysse("logo") end			-- logo
function se_qsave()   sysse("qsave") end		-- qsave
function se_qload()   sysse("qload") end		-- qload
function se_start()	  sysse("title") end		-- title start
----------------------------------------
-- SystemVoice
----------------------------------------
-- system voice
function sysvo_func(p)
	local name = p.name
	local com = p.com
	sysvo(name, com)
end
----------------------------------------
function sysvo(name, com)
	local s = init.sysvo_func
	local z = csv.sysse.sysvo
	local p = com
	local c = com
	if type(p) == "string" then
		p = {}
	else
		c = nil
	end
	local sync = p and (p.wait or p.sync)

	-- 停止
	sesys_stop("sysvo")

	-- 音量確認
	local v1 = conf.sysvo or conf.sysse
	local v2 = conf.fl_sysvo or conf.fl_sysse
	if v1 ==0 or v2 and v2 == 0 then
--		message("通知", "音量が 0 でした", name)

	-- エラー
	elseif not name then
		message("通知", "不明なsysvoです")

	-- パス指定があればvoiceを呼び出す
	elseif name:find("sysvo/") then
		message("通知", name, "を再生します")
		local path = name..game.soundext
		sesys_play("sysvo", path, { id=1, sync=(sync) })

	-- 専用ルーチンを呼び出す
	elseif s and _G[s] then
		_G[s](name, wait)

	-- キャラ決め打ち
	elseif c then
		local v = z[name][c] or {}
		local m = #v
		if m > 0 then
			-- 再生
			local r = e:random() % m + 1
			local path = ":sysvo/"..v[r]..game.soundext
			sesys_play("sysvo", path, { id=1, sync=(sync) })
		end

	-- 汎用ルーチン
	elseif z[name] and z.charlist then
		-- キャラ取得
		local c = {}
		local v = z[name]

		--(AD)：コール系は設定に関わらず再生
		if name == "brand" or name == "titlecall" or name == "trial" then
			for n, i in pairs(v) do
				table.insert(c, n)
			end
		else
			for n, i in pairs(v) do
				if conf["svo_"..n] == 1 then table.insert(c, n) end
			end
		end
		local m = #c
		if m == 0 then
--			message("通知", "sysvo全キャラ無効化")
			return
		end

		-- キャラを選ぶ
		local r = e:random() % m + 1
		local n = c[r]

		-- ボイスを選ぶ
		local r = e:random() % #v[n] + 1
		local f = v[n][r]

		-- 再生
		local sv   = csv.sysse.sysvo.sysvowait or {}
		local exok = sv[name] and "exitok"
		local path = ":sysvo/"..f..game.soundext
		sesys_play("sysvo", path, { id=1, nosave=(exok), sync=(sync) })

	-- 不明
--	else
--		message("通知", name, "は不明なsysvoです")
	end
end
----------------------------------------
