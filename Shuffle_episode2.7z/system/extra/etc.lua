----------------------------------------
-- おまけ／動画
----------------------------------------
-- 動画初期化
function exf.mvinit()

	if not appex.movi then appex.movi = {} end
	
	local stm = 0
	local stc = 0
	for set, v in pairs(csv.extra_scene) do
		local p = v[1]
		if p == "ed" then 
			local n = v[2] -- とりあえず１ページ目に固定する
			local m = table.maxn(v) - 2
			-- 保存
			local fl = v[3]
			local fx = gscr.scene[set]
			if not appex.movi[1]	then appex.movi[1] = {} end
			if not appex.movi[1][n] then appex.movi[1][n] = { file=(fl), label=(v[4]), thumb=(v[5]), flag=(fx),name="ed" } end
			if fx then stc = stc + 1 end
			stm = stm + 1
		end
	end
	-- OPムービーは強制開放
	appex.movi[1][6] = { id="op", file="op", flag=(true),name="mv" }
end
----------------------------------------
-- ページ生成
function exf.mvpage()
	local p, page, char = exf.getTable()
	local px = p.p
	-- ページ本体
	if px.pagemax then
--		local mask = getBtnInfo("cg01")
		local path = game.path.ui
		for i=1, px.pagemax do
			local mv = px[char][i]
			local nm = "cg"..string.format("%02d", i)
			local id = getBtnID(nm)
			if mv.flag then
				lyc2{ file=(":thumb/"..mv.file), id=(id..".5"), x=(px.tx), y=(px.ty)}
			else
				lydel2(id..".5")
				setBtnStat(nm, 'c')
--				lyc2{ file=(path..mask.file), id=(id..".-1"), clip=(mask.clip_c)}
			end
		end
	end
end
----------------------------------------
-- 
----------------------------------------
-- 動画再生
function exf.playmovie(no)
	flg.btnstop = true
	local p, pg, ch = exf.getTable()
	local z = p.p[ch][no]

	-- ムービー再生
	if z.name == "mv" then
		local id   = z.id
		local v    = init.movie[id] or {}		-- movie設定
		local file = v.file	or id				-- 仮想ファイル
		local path = game.path.movie
		local exp  = game.movieext

		-- 停止キー
		local key = "1"
		for k, v in pairs(csv.advkey.list.MWCLICK) do
			key = key..','..k
		end
		e:tag{"keyconfig", role="0", keys=(key)}

		-- 再生中のbgmを保存しておく
		appex.playbgm = getplaybgmfile()

		-- 再生
		message("通知",path..file..exp.."を再生します")
		local time = init.normal
		allsound_stop{ time=(time) }
		lyc2{ id="600", file=(init.black)}
		estag("init")
		estag{"uitrans", time}
		estag{"video", file=(path..file..exp), skip=(1)}
		estag{"keyconfig", role="0", keys="124"}			-- key戻し
		estag{"extra_movieend"}
		estag()
	else
		exf.edjump(no)
	end
end
-- 
function exf.edjump(no)
	local p, page, char = exf.getTable()
	local z = appex.movi.pagemax
	local n = (page-1) * z + no
	local v = p.p[char][n]
	if v.flag then
		local file = v.file

		message("通知", file, ":", v.label, "を呼び出します")
		-- 再生中のbgmを保存しておく
		local b = getplaybgmfile()
		appex.playbgm = b
		-- シーンを閉じる
		e:tag{"lydel", id="400"}
		e:tag{"lydel", id="500"}
		e:tag{"lydel", id="600"}
		flg.ed = v
		e:tag{"jump", file="system/ui.asb", label="exscene_jump"}
	end
end
----------------------------------------
function extra_movieend()
	-- bgm再生
	local fl = getplaybgmfile(appex.playbgm)
	if fl then
		bgm_play{ file=(fl), sys=true }
		appex.playbgm = nil
	else
		title_bgm()
	end

	lydel2("600")
	uitrans()
	flg.btnstop = nil
end
----------------------------------------
-- staffroll
function movie_staffroll()
	staffroll{}
end
----------------------------------------
-- staffroll exit
function movie_staffroll_exit()
	flg.btnstop = nil
	exf.bgmrestart()	-- bgm再開
	setonpush_ui()		-- 念のためキー設定
end
----------------------------------------
