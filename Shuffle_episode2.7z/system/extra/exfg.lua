----------------------------------------
-- おまけ／立ち絵鑑賞
----------------------------------------
-- FG初期化
function exf.fginit()

	if not appex.exfg then appex.exfg = {} end
	sys.exfg = { dummy=0 }

	-- FG取得
	local stm = 0
	local stc = 0
	for set, v in pairs(csv.extra_cgmode) do
		local p = v[1]
		local n = v[2]
		local m = table.maxn(v) - 2

		-- 差分の開き具合を確認しておく
		local o = 0
		for i=1, m do
			local nm = v[i + 2]
			if gscr.ev[nm] then o = o + 1 end
		end

		-- 保存
		local fl = gscr.evset[set]
		if not appex.exfg[p]	then appex.exfg[p] = {} end
		if not appex.exfg[p][n] then appex.exfg[p][n] = { set=(set), file=(set), open=(o), max=(m), tbl=(v), flag=(fl) } end
		if fl then stc = stc + 1 end
		stm = stm + 1
	end

	appex.exfg.pagemax = 0
end
----------------------------------------
-- ページ生成
function exf.fgpage()
	local p, page, char = exf.getTable()
	local px = p.p


end
----------------------------------------
-- 
----------------------------------------
-- FG表示
function exf.fgview(no)
	flg.btnstop = true
	local p, pg, ch = exf.getTable()
	local z = p.p[ch][p.head + no]

	-- 下処理
	local c = 0
	flg.excgbuff = {}
	for i=1, z.max do
		local n = z.tbl[i+2]
		if gscr.ev[n] then
			table.insert(flg.excgbuff, n)
			c = c + 1
		end
	end

	flg.excgbuff.count = 1
	flg.excgbuff.max   = c
	flg.excgbuff.set   = z.set
	e:tag{"call", file="system/ui.asb", label="cgviewer"}
end
----------------------------------------
-- FGボタン生成
----------------------------------------
