----------------------------------------
-- おまけ／CG
----------------------------------------
-- CG初期化
function exf.cginit()

	if not appex.cgmd then appex.cgmd = {} end

	-- 強制開放
--[[
	gscr.evset.gameover = true
	gscr.evset.op05 = true
	gscr.evset.op09 = true
	gscr.evset.op11 = true
	gscr.evset.op12 = true
	gscr.ev.gameover = true
	gscr.ev.op05 = true
	gscr.ev.op09 = true
	gscr.ev.op10 = true
	gscr.ev.op11 = true
	gscr.ev.op12 = true
]]
	-- CG取得
	local stm = 0
	local stc = 0
	for set, v in pairs(csv.extra_cgmode) do
		local p = v[1]
		local n = v[2]
		local m = table.maxn(v) - 2

		-- 差分の開き具合を確認しておく
		local o = 0
		for i=1, m do
			local nm = v[i + 2]
			if gscr.ev[nm] then o = o + 1 end
		end

		-- 保存
		local fl = gscr.evset[set]
		if not appex.cgmd[p]	then appex.cgmd[p] = {} end
		if not appex.cgmd[p][n] then appex.cgmd[p][n] = { set=(set), file=(set), open=(o), max=(m), tbl=(v), flag=(fl) } end
		if fl then stc = stc + 1 end
		stm = stm + 1
	end

	-- パーセント
--	local px = stc == stm and 100 or percent(stc, stm)
--	exf.percent("500.nm", px, "num01")

	-- 各ページのボタン数
	local mx = appex.cgmd.pagemax
	for i, v in ipairs(appex.cgmd) do
		appex.cgmd[i].bmax = #v
		appex.cgmd[i].pmax = math.ceil(#v / mx)
	end
end
----------------------------------------
-- ページ生成
function exf.cgpage()
	local p, page, char = exf.getTable()
	local px = p.p

	-- ページ本体
	local max = px.pagemax
	if max then
--		local m    = getBtnInfo("thumb")
--		local path = game.path.ui..m.file
--		local clip = m.cx..","..(m.ch * (char-1))..","..m.cw..","..m.ch
--		tag{"lyprop", id=(m.idx), visible="0"}
		for i=1, max do
			local hd = (page - 1) * max
			local mv = px[char][p.head + i]
			local nm = "cg"..string.format("%02d", i)
			local id = getBtnID(nm)

			-- ボタン
			if not mv then
				tag{"lyprop", id=(id), visible="0"}
			else
				tag{"lyprop", id=(id), visible="1"}
				local idt = id..".5"
				if mv.flag then
					lyc2{ id=(idt), file=(":thumb/"..mv.file), x=(px.tx), y=(px.ty)}
					setBtnStat(nm, nil)
				else
--					lyc2{ id=(idt), file=(path), x=(px.tx), y=(px.ty), clip=(clip)}
					lydel2(idt)
					setBtnStat(nm, 'c')
				end
			end
		end

		-- ページ番号表示
--[[
--		exf.pageno("no01", page)
--		exf.pageno("no02", px[char].pmax)
		for i=1, px[char].pmax do
			local name = "page"..string.format("%02d", i)
			if i == page then
				setBtnStat(name, 'c')
			else
				setBtnStat(name, nil)
			end
		end
]]
		-- キャラ表示
		local m = #px
		for i=1, m do
			local name = "page"..string.format("%02d", i)
			if i == char then
				setBtnStat(name, 'c')
			else
				setBtnStat(name, nil)
			end
		end
	end
end
----------------------------------------
--
----------------------------------------
function cgmode_over(e, p)
	local bt = p.name
	local v  = bt and getBtnInfo(bt)
	if v then
		local nm = v.p3
		local z  = csv.mw[nm]
		local id = v.idx..'.'..z.id
		local px = get_uipath()..z.file
		lyc2{ id=(id), file=(px), x=(z.x), y=(z.y), clip=(z.clip) }
	end
end
----------------------------------------
function cgmode_out(e, p)
	local bt = p.name
	local v  = bt and getBtnInfo(bt)
	if v then
		local nm = v.p3
		local z  = csv.mw[nm]
		local id = v.idx..'.'..z.id
		lydel2(id)
	end
end
----------------------------------------
-- 
----------------------------------------
-- CG表示
function exf.cgview(no)
	flg.btnstop = true
	local p, pg, ch = exf.getTable()
	local z = p.p[ch][p.head + no]

	-- 下処理
	local c = 0
	flg.excgbuff = {}
	for i=1, z.max do
		local n = z.tbl[i+2]
		if gscr.ev[n] then
			table.insert(flg.excgbuff, n)
			c = c + 1
		end
	end

	flg.excgbuff.count = 1
	flg.excgbuff.max   = c
	flg.excgbuff.set   = z.set
	e:tag{"call", file="system/ui.asb", label="cgviewer"}
end
----------------------------------------
-- 
----------------------------------------
-- cg表示終了
function extra_cg_viewerexit()
--	exf.bgmrestart()
	flg.btnstop = nil
	flg.advdrag = nil
	flg.upedge = nil
end
----------------------------------------
-- cg表示
function extra_cg_viewer()
	local v = flg.excgbuff
	local c = v.count
	local n = v[c]

	message("通知", c.."/"..v.max, n)

	-- 表示
	local time = 300
	local rule = init.rule_cgmode

	-- 振り分け
	local sw = {
		-- movie
		mvop = function()	extra_cg_movie("mvop") end,
		mvpv = function()	extra_cg_movie("mvpv") end,

		-- scroll
		scroll = function()
			local time = 30000
			tween{ id="600", x=("0,-"..game.width), time=(time)}
			eqwait(time)
			eqtag{"lytweendel", id="600"}
		end
	}
	if sw[n] then
		sw[n]()
	elseif n then
		e:tag{"lydel", id="600"}
		local s = v.set
		local m = ':ev/'..s.."/"
		local h = n:sub(1, 2)
		if h == "bg" then m = ":bg/" end
		if h == "sd" then m = ":sd/"..s.."/" end

		-- scroll
		local tbl = {  }	--ev_027_yz=0, ev_033_ri=720, ev_034_yu=720 }
		local no  = tbl[s]
		local wd  = 0
		local id  = "600.1"
		lyc2{ id="600.0", file=(init.black), alpha="192"}

		-- 特殊処理
		if e:isFileExists(m..n..".ipt") then
			readImage("600.1.m.a", { path=(m), file=(n) })
			tag{"lyprop", id="600.1.m.a", intermediate_render="1"}

			if no then
				-- x/y
				local g = game
				local i = ipt.base
				local x = i.x
				local y = i.y
				wd = y

				-- scroll
				if no == 2 then
					tag{"tweenset"}
					systween{ id=(id), y=("0,"..-y)	 , time="10000", delay="2000"}
					systween{ id=(id), y=(-y..","..y), time="20000", yoyo="-1"}
					tag{"/tweenset"}
				end
			end
		else
			local t = nil

			-- 表示
			local idx = id..".s"
			lyc2{ id=(idx), file=(m..n)}

			-- サイズ補正
			if no then
				e:tag{"var", name="t.ly", system="get_layer_info", id=(idx), style="map"}
				local x = 0
				local y = 0
				local w = tn(e:var("t.ly.width"))
				local h = tn(e:var("t.ly.height"))
				local g = game

				-- x/y
				if w ~= g.width  then x = math.floor(g.ax - w / 2) end
				if h ~= g.height then y = math.floor(g.ay - h / 2) end
				e:tag{"lyprop", id=(idx), left=(x), top=(y)}
				wd = y

				-- scroll
				if no == 2 then
					tag{"tweenset"}
					systween{ id=(idx), y=(y..",0")	  , time="10000", delay="2000"}
					systween{ id=(idx), y=("0,"..(y*2)), time="20000", yoyo="-1"}
					tag{"/tweenset"}
				end
			end
		end

		-- drag
		if no then
			local h = game.height
			lyc2{ id="600.s", file=(init.black), alpha="0", draggable="1", dragarea=("0,"..-h..",0,"..h)}
			lyevent{ id="600.s", dragin="cgmode_draginit", drag="cgmode_drag", dragout="cgmode_dragout"}
			flg.upedge = true
			flg.cgmode = { y=no, h=wd, idx=(id) }
			e:tag{"lyprop", id=(id), top=(no)}
		end

		-- 上下黒線
		if game.crop then
--			lyc2{id="1.-1", width="8", height="1", color="0xfff00000", y="-1", visible="0"}
			tag{"lyprop", id="600", top=(game.crop)}
		end
	end

	-- 次
	local r = 0
	c = c + 1
	if c > v.max then r = 1 end
 	flg.excgbuff.count = c
	e:tag{"var", name="t.check", data=(r)}
	e:tag{"var", name="t.trns" , data=(time)}
	e:tag{"var", name="t.rule" , data=(rule)}
end
----------------------------------------
function cgmode_draginit(e, p)
	flg.advdrag = true
	flg.cgmode.m = e:getMousePoint()
end
----------------------------------------
function cgmode_drag(e, p)
	local m = e:getMousePoint()
	local v = flg.cgmode
	local n = v.y
	local h = v.h
	local y = n + m.y - v.m.y
	if y < h then y = h elseif y > -h then y = -h end
	tag{"lyprop", id=(v.idx), top=(y)}
	flip()
end
----------------------------------------
function cgmode_dragout(e, p)
	local m = e:getMousePoint()
	local v = flg.cgmode
	local n = v.y
	local h = v.h
	local a = m.y - v.m.y

	-- click
	if -10 < a and a < 10 then
		flg.exclick = 124
		flg.upedge = nil
	else
		local y = n + a
		if y < h then y = h elseif y > -h then y = -h end
		flg.cgmode.y = y

		tag{"lyprop", id=(v.idx), top=(y)}
		tag{"lyprop", id=(p.id), left="0", top="0"}
		flip()
	end
	flg.advdrag = nil
end
----------------------------------------
