----------------------------------------
-- おまけ／共通化
----------------------------------------
exf = {}
----------------------------------------
exf.table = {
	cgmd = { ui="ui_cgmode" , init="cginit", view="cgpage", vo=true, flag="ev"    },							-- CG鑑賞
	scen = { ui="ui_scene"  , init="scinit", view="scpage", vo=true, flag="scene" },							-- シーン鑑賞
	bgmd = { ui="ui_bgmmode", init="bginit", view="bgpage", vo=true, flag="bgm"  , reset="exbgm_reset"   },		-- 音楽鑑賞
	movi = { ui="ui_movie"  , init="mvinit", view="mvpage", vo=true, flag="movie" },							-- 動画鑑賞
	exfg = { ui="ui_fgmode" , init="fginit", view="fgpage", vo=true, flag="exfg"  },							-- 立ち絵鑑賞
}
----------------------------------------
function extra_cgmode()	extra_init("cgmd") end
function extra_scene()	extra_init("scen") end
function extra_bgmmd()	extra_init("bgmd") end
function extra_movie()	extra_init("movi") end
----------------------------------------
-- 呼び出し初期化
function extra_init(name, flag)
	local p = exf.table[name]
	message("通知", name, "を開きました")

--	flg.titleextra = true

	-- sysvo
	if not flag and p.vo then sysvo(name) end

--	bgm_play{ file=(init.title_bgm) }

	-- 念のため入れておく
	flg.ui = {}
	setonpush_ui()

	-- テーブルがなければ作成
	if not appex then appex = {} end
	if not appex[name] then appex[name] = {} end
	if not gscr[name] then gscr[name] = {} end
	if not sys.extr then sys.extr = { music=100, play=1, vol=(conf.bgm), buff=0 } end

	-- 開かれていたら閉じる
	local nm = appex.name
	local rs = nm and exf.table[nm].reset
	if rs and exf[rs] then exf[rs]() elseif rs and _G[rs] then _G[rs]() end
	appex.name = name
	if init.extra_pagesave == "on" then gscr.extraname = name end

	-- ボタン描画
	csvbtn3("extr", "500", csv[p.ui])

	-- ページ数
	local cxt = csv[p.ui]
	if cxt[2] then
		appex[name].pagemax = cxt[2]	-- ページ内のボタン数
		appex[name].lx = cxt[3]			-- サムネイルx数
		appex[name].ly = cxt[4]			-- サムネイルy数
		appex[name].tx = cxt[5]			-- サムネイルx補正
		appex[name].ty = cxt[6]			-- サムネイルy補正
	end

	-- データを作っておく
	if p.init and exf[p.init] then exf[p.init]() end

	-- 表示
	extra_page()

	-- アニメーション
	if flag == "title" then
		uiopenanime("extra")
	else
		uitrans()
	end
end
----------------------------------------
-- ページ処理
function extra_page()
	local p, page, char = exf.getTable()
	local nm = p.name

	-- キャラボタン
--	setBtnStat("page0"..char, 'c')		-- 

	-- 各ページへ
	local s = p.t.view	-- exf.table[name].page
	if s and exf[s] then exf[s]() end
--	exf.mvpage()

	-- フラグで開放
--	local p3 = tn(get_eval("g.allclear"))
--	if p3 == 0 then setBtnStat("bt_bgm", 'd') end

	-- 保存
	if nm == "bgmd" then exf.musicpage() end
	gscr[nm][char].page = page
end
----------------------------------------
-- 閉じる
function extra_exit()
	ReturnStack()	-- 空のスタックを削除
	se_cancel()

	-- 個別exitがあれば呼ぶ
	local p = exf.getTable()
	local ex = p.t and p.t.exit or p.t.reset
	if ex and exf[ex] then exf[ex]() elseif ex and _G[ex] then _G[ex]() end

	-- 削除
	appex = nil
	sys.extr = nil

	-- アニメーション
	sysvo("back")
	local tm = init.ui_fade
	local t2 = tm * 2
	local i1 = "500.z"				-- body
	local i2 = getBtnID("bg02")		-- black
	local i3 = "500.sy.1"			-- up
	local i4 = "500.sy.2"			-- dw
	local v1 = getBtnInfo("bg03")	-- up info
	local v2 = getBtnInfo("bg04")	-- dw info
	local rule = init.rule_extraoff
	estag("init")
	if rule then
		estag{"lyprop", id=(i1), visible="0"}
		estag{"uitrans", tm}
		estag{"lyprop", id=(i2), visible="0"}
		estag{"systween", { id=(i3), y=("0,"..-v1.h), time=(t2)}}
		estag{"systween", { id=(i4), y=("0,".. v1.h), time=(t2)}}
		estag{"uitrans", t2}
	else
		estag{"lyprop", id=(i1), visible="0"}
		estag{"lyprop", id=(i2), visible="0"}
	end
	estag{"delbtn", 'extr'}		-- 削除
	estag{"title_init"}			-- titleへ
	estag()
end
----------------------------------------
-- 
----------------------------------------
-- 変数まとめて取得
function exf.getTable()
	local name = appex.name
	local px   = appex[name]
	local char = px.char or 1
	local tbl  = exf.table[name]

	if not gscr[name][char] then gscr[name][char] = {} end
	local page = gscr[name][char].page or 1
	local head = (page - 1) * px.pagemax

	local r = {
		name = name,
		char = char,
		page = page,
		head = head,
		p    = px,
		t    = tbl,
	}
	return r, page, char
end
----------------------------------------
-- ページ番号処理
function exf.pageno(name, no)
	local v = getBtnInfo(name)
	if v.dir == "width" then
		local z = no * v.cw + v.cx
		local c = z..","..v.cy..","..v.cw..","..v.ch
		tag{"lyprop", id=(v.idx), clip=(c)}

--	dump(v)

	end
end
----------------------------------------
-- パーセント処理
function exf.percent(id, num, name, flag)
	local a = NumToGrph3(num)
	local v = getBtnInfo(name)
	local w = v.w
	local h = v.h
	local z = ",0,"..w..","..h

	-- 100
	if a[1] == 1 then tag{"lyprop", id=(id..".1"), clip=(w..z)}
	elseif flag then  tag{"lyprop", id=(id..".1"), clip=((11 * w)..z)}
	else			  tag{"lyprop", id=(id..".1"), clip=("0,"..z)} end

	-- 10 / 1
	tag{"lyprop", id=(id..".2"), clip=((a[2] * w)..z)}
	tag{"lyprop", id=(id..".3"), clip=((a[3] * w)..z)}
end
----------------------------------------
-- 
----------------------------------------
-- クリック共通
function extra_click()
	local bt = btn.cursor
	if bt then
		local v = getBtnInfo(bt)
		local c = v.p1
		local n = tn(v.p2)

--		message("通知", bt.."が選択されました", c, n)

		local sw = {
			bt_exit = function() se_ok() adv_exit() end,

			extra	= function() exf.clickextra(v.p2) end,
			click	= function() exf.clickcheck(n) end,
			box		= function() exf.clickbox(n) end,
			char	= function() exf.charchange(n) end,
			page	= function() exf.pagechange(n) end,
			charadd = function() exf.addchar(n) end,
			pageadd = function() exf.addpage(n) end,

			bgm		= function() exf.clickbgm(n) end,		-- bgm直接再生
			play	= function() exf.clickbgmbtn(v.p2) end,	-- bgmプレイヤーボタン
		}
		local nm = c or bt
		if sw[nm] then sw[nm](n) end

--[[
		-- cg view
		if n then extra_cg_view(n)

		-- page
		elseif c then extra_cg_pagech(c)
		elseif bt == "bt_bgm"	then extra_cg_exit(e, "extra_bgm_init")
		elseif bt == "bt_scene" then extra_cg_exit(e, "extra_scene_init")
		elseif bt == "bt_cat"   then extra_cg_exit(e, "extra_cat_init")

		elseif bt == "bt_exit" then adv_exit()
		end
]]
	end
end
----------------------------------------
-- おまけ移動
function exf.clickextra(nm)
	if exf.table[nm] then
		se_ok()
		extra_init(nm)
	end
end
----------------------------------------
-- 本体クリック
function exf.clickcheck(no)
	local p, pg, ch = exf.getTable()
	local s = (pg-1) * (p.p.pagemax or 0) + no
	if p.p[ch][s].flag then
		se_ok()
		local sw = {
			cgmd = function() exf.cgview(no) end,
			scen = function() exf.sceneview(no) end,
			movi = function() exf.playmovie(no) end,
		}
		if sw[p.name] then sw[p.name]() end
	end
end
----------------------------------------
-- キャラ変更
function exf.charchange(no)
	local p = exf.getTable()
	local nm = p.name

	-- cg/scene
	if nm == "cgmd" or nm == "scen" then
		se_ok()
		setBtnStat("page0"..p.char, nil)	-- キャラボタン有効化
		appex[p.name].char = no				-- char保存
		extra_page()
		flip()

	-- movie/box
	elseif nm == "movi" or nm == "ebox" then
		se_ok()
		if appex.cgmd then appex.cgmd.char = no	end		-- char保存
		extra_cgmode()
	end
end
----------------------------------------
-- ページ変更
function exf.pagechange(no)
	local p, pg, ch = exf.getTable()
	local nm = p.name
--	if nm == "cgmd" or nm == "scen" then
		se_ok()
		local px = p.p[ch]
		local mx = px.pmax
--		pg = pg + no
--		if pg < 1 then pg = mx elseif pg > mx then pg = 1 end
		gscr[nm][ch].page = no
		extra_page()
		flip()
--	end
end
----------------------------------------
-- キャラ変更／加算
function exf.addchar(no)
	local p, pg, ch = exf.getTable()
	local nm = p.name
	if nm == "cgmd" or nm == "scen" then
		se_ok()
		local mx = #p.p
		ch = ch + no
		if ch < 1 then ch = mx elseif ch > mx then ch = 1 end
		appex[nm].char = ch				-- char保存
		extra_page()
		flip()
	end
end
----------------------------------------
-- ページ変更／加算
function exf.addpage(no)
	local p, pg, ch = exf.getTable()
	local nm = p.name
	if nm == "cgmd" or nm == "scen" then
		se_ok()
		local px = p.p[ch]
		local mx = px.pmax
		pg = pg + no
		if pg < 1 then pg = mx elseif pg > mx then pg = 1 end
		gscr[nm][ch].page = pg
		extra_page()
		flip()
	end
end
----------------------------------------
-- slider
----------------------------------------
-- 位置調整
function extra_pageslider_pos(bt)
	local p, page, char = exf.getTable()
	local px = p.p[char]
	local mx = px.pmax -1				-- ページ最大値
	local no = page - 1					-- ページ現在値

	-- slider
	local v  = getBtnInfo(bt)
	local dr = v.com == "xslider"
	local wh = (dr and v.w or v.h) - v.p2

	-- 計算
	local n1 = percent(no, mx)		-- page/maxから%を出す
	local n2 = repercent(n1, wh)	-- page/maxから%を出す

	-- 移動
	local id = v.idx..".10"
	if dr then	tag{"lyprop", id=(id), left=(n2)}
	else		tag{"lyprop", id=(id), top =(n2)} end
end
----------------------------------------
-- クリック時動作
function extra_clickpageslider(e, p)
	local pr = p.p

	-- 計算
	local p, page, char = exf.getTable()
	local px = p.p[char]
	local mx = px.pmax						-- ページ最大値
	local n1 = repercent(pr, mx)			-- page/maxから%を出す
	n1 = n1 + 1
	if n1 > mx then n1 = mx end

	-- 保存
	local nm = p.name
	gscr[nm][char].page = n1

	-- 描画
	extra_page()
end
----------------------------------------
-- movie
----------------------------------------
-- 
function exf.movieplay(file)
	local time = 1500
--	allkeyoff()

	-- 再生中のbgmを保存しておく
	local b = getplaybgmfile()
	flg.extra_playbgm = b

	bgm_stop{ time=(time) }

	-- 停止キー
	local ky = getKeyString("CANCEL")
	tag{"keyconfig", role="1", keys=(ky)}

	-- path
	local n = "movierename_"..file
	if init[n] then file = init[n] end
	local path = game.path.movie..file..game.movieext

	lyc2{ id="900", file=(init.black) }
	estag("init")
	estag{"uitrans", (time)}
	estag{"video", file=(path), skip="2"}
	estag{"keyconfig", role="1", keys=""}
	estag{"lydel", id="900"}
	estag{"uitrans", (time)}
	estag{"extra_movieend"}
	estag()
end
----------------------------------------
function extra_movieend()
	-- bgm再開
	local fl = getplaybgmfile(flg.extra_playbgm)
	if fl then
		bgm_play{ file=(fl), sys=true }
		flg.extra_playbgm = nil
	else
		title_bgm()
	end
end
----------------------------------------
