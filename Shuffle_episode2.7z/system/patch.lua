----------------------------------------
-- パッチ処理
----------------------------------------
function init_patch()
	e:tag{"var", name="t.c", system="get_exe_parameter"}
	local c  = e:var("t.c.com")
	local ln = get_language(true)
	if sys.dmmcheck and (c == "start" or not debug_flag) and game.os == "windows" and ln == "ja" and not getTrial() then
		local patch_url = "http://world-actor.com/patch-notes/info_ryusei.csv"

--		message("通知", "ハッチ確認中")

		e:setEventHandler{ onEnterFrame="patch_vsync" }

		flg.patch = true
		e:tag{"caption", data="Checking patch..."}
		e:tag{"httpget", url=(patch_url),
			varname_code = "t.code",
			varname_data = "t.data",
		}
		eqtag{"calllua", ["function"]="patch_read"}
	end
end
----------------------------------------
function patch_read(e, p)
	e:setEventHandler{ onEnterFrame = "" }
	flg.patch = nil
	local code = e:var("t.code")
	if code ~= "200" then return end

	-- data
	local data = code_utf8(e:var("t.data")):gsub("\r\n", "\n")
	local dx   = explode("\n", data)
	local ax   = explode("," , dx[1])
	if not ax[1] or ax[1] == "" then return end

	-- text
	local date = ax[1]
	local ver  = ax[2]
	local url  = ax[3]
	local titl = ax[4]
	local text = ax[5]:gsub("[n]", "\n")
	local ck   = sys.patchdate or ""
	if ck == date then return end
	sys.patchdate = date

	-- 未読追記
	local mx = #dx
	if mx > 1 then
		local tb = "\n--------------------------------\n"
		for i=2, mx do
			local a = explode("," , dx[i])
			if a[1] == "" then break
			elseif a[1] == ck then break
			else
				local a1 = a[1] or ""
				local a2 = a[2] or ""
				local a3 = a[3] or ""
				local a4 = a[4] or ""
				local a5 =(a[5] or ""):gsub("[n]", "\n")
				if ver  == "" and a2 ~= "" then ver  = a2 end
				if url  == "" and a3 ~= "" then url  = a3 end
				if titl == "" and a4 ~= "" then titl = a4 end
				text = text..tb..a4.." ("..a1..")\n"..a5
			end
		end
	end

	-- caution
	if ver == "" and url == "" and titl and text then
		tag_dialog({ title=(titl), message=(text) })

	-- url
	elseif ver and url and titl and text then
		tag_dialog({ varname="t.yn", title=(titl), message=(text)}, "patch_readnext", url)
	end
end
----------------------------------------
function patch_readnext(url)
	local yn = e:var("t.yn")
	if yn == "1" then
		e:tag{"openbrowser", url=(url)}
--		e:tag{"exit"}
	end
end
----------------------------------------
function patch_vsync()
	if flg.patch then
		if e:isDownEdge(2) or e:isDownEdge(27) or e:isDownEdge(139) then
			message("通知", "パッチ確認をキャンセルしました")
			e:tag{"var", name="s.http.cancel", data="1"}
			flg.patch = nil
		end
	end
end
----------------------------------------
