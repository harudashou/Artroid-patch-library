----------------------------------------
-- 起動設定
----------------------------------------
-- ■ ブランドロゴ
----------------------------------------
function brand_logo() callscript("system", init.brand_script) end
----------------------------------------
function brandlogo(p)
	local file = p.file
	local mode = p.mode
	local path = game.path.ui
	local v  = flg.logo or {}
	local id = 10
	local tr = { sys=2, time=(v.time) }

	-- 初期化
	if mode and mode ~= "end" then
		message("通知", "ブランドロゴを表示します")
		if not flg then flg = {} end
		flg.logo = {}
		flg.logo.file  = init[mode] or path..mode
		flg.logo.time  = tn(p.time or 1000)
		flg.logo.wait  = tn(p.wait or 2500)
		flg.logo.count = 1

		autoskip_ctrl()
--		autoskip_disable()
		if p.key == "disable" then allkeyoff() end

		e:tag{"lydel", id="startmask"}

		-- 表示
		local v = flg.logo
		lyc2{ id=(id), file=(v.file) }
		uitrans{ sys=2, time=(v.time) }

	-- リセット
	elseif not file then
		estag("init")
		estag{"lyc2", { id=(id), file=(v.file) }}
		estag{"uitrans", tr}
		estag{"brandlogo_windowsexit"}
		flg.logo = nil
		allkeyon()

		-- title cache
		if mode ~= "end" then
			estag{"title_cache"}
			estag{"title_cachewait"}

			-- titleへ
			local fl = init.start_bg or "black"
			estag{"lydel", id=(id)}
			estag{"lyc2", {id="2", file=(init[fl])} }
			estag{"jump", file="system/first.iet", label="title"}
		else
			estag{"lydel", id=(id)}
			estag{"autoskip_ctrl", true}
		end
		estag()

	-- 画像表示
	else
		estag("init")
		local m = tn(p.movie) or 0
		if m == 0 then
			estag{"lyc2", { id=(id), file=(path..file) }}
			estag{"uitrans", tr}
		end

		-- brand call
		if p.sysvo then estag{"sysvo", p.sysvo} end

		-- movie
		if m == 2 then
			local px = game.path.movie..file..".ogv"
			estag{"video", id=(id), file=(px)}
			estag{"flip"}
			estag{"eqwait", { video=(id), input="2"} }
		elseif m ~= 0 then
			estag{"keyconfig", role="1", keys=(getKeyString("ALL"))}
			local px = game.path.movie..file..game.movieext
			estag{"video", file=(px), skip="2"}
			estag{"keyconfig", role="1", keys=""}
		else
			-- wait
			local wa = p.wait or v.wait
			estag{"eqwait", wa }
		end

		local bx = p.bg or v.file if bx == "none" then bx = nil end
		if bx then
			if bx == "black" or bx == "white" then bx = init[bx] end
			estag{"lyc2", { id=(id), file=(bx) }}
			estag{"uitrans", tr}
		end
		estag()
	end
end
----------------------------------------
-- 動画再生中に×ボタンが押されると抜けられなくなる対処
function brandlogo_windowsexit()
	if gameexitflag then tag{"exit"} end
end
----------------------------------------
-- ウィンドウサイズ
----------------------------------------
-- module名管理
function getWindowSizeModule()
	return "iarsys.dll"
end
----------------------------------------
-- windowsサイズ変更初期化
function windows_screeninit()
	local s = init.game_screenaspect
	if s and game.trueos == "windows" then
		local m = getWindowSizeModule()
		if isFile(m) then
			windows_screenaspect = true
			local px = e:var("s.savepath").."/"
			tag{"callnative", result="t.ret", module=(m), method="initialize", param=("path="..px)}
			setWindowsScreenSize()
		end
	end
end
----------------------------------------
-- スクリーンサイズ変更
function setWindowsScreenSize()
	if windows_screenaspect then
		local s = init.game_screenaspect
		local w = 1280
		local h = math.floor(w / s[1] * s[2])

dump(s)
message("ok", w, h)

		tag{"callnative", result="t.ret", module=(getWindowSizeModule()), method="setwndsize", param=("width="..w..",height="..h)}
	end
end
----------------------------------------
-- ■ font初期化
function font_init()
	-- langpack読み込み
	flg.textfont = nil
	local ln = get_language(true)
	local px = "system/table/list_"..game.os.."_"..ln..".tbl"
	e:include(px)

	-- OSとバージョン
	local s  = get_gamever() or "1.0"
	game.ver = s
	scr.gamever = s
--	e:tag{"var", name="game.ver", data=(s)}
	set_caption()		-- ウインドウタイトル設定

	-- cache
	local c = 0
	for name, v in pairs(lang.font) do
		if v.show == 'cache' then
			local id = 'fontcache.'..c
			set_textfont(name, id)
			e:tag{"chgmsg", id=(id), layered="1"}
			e:tag{"print", data="　"}
--			e:tag{"rp"}
			e:tag{"/chgmsg"}
			c = c + 1
		elseif v.show ~= 'none' then
			set_textfont(name, name)
		end
	end

	if c ~= 0 then
		e:tag{"lyprop", id="fontcache", left=(game.width), visible="0"}
	end
end
----------------------------------------
-- テキストレイヤーにfontを設定
function set_textfont(name, id, flag)
--	console('【通知】テキストレイヤー'..name..'('..id..')を設定しました')

	-- １回だけ通過する
	if not flg.textfont then flg.textfont = {} end
	if not flg.textfont[name] then flg.textfont[name] = {} end
	if not flag and flg.textfont[name][id] then return end
	flg.textfont[name][id] = true

	-- 登録
	local font = tcopy(lang.font[name])
	local ly   = font.layered or 0
	e:tag{"chgmsg", id=(id), layered=(ly)}
	e:tag{"fontinit"}
	font[1] = 'font'
	font.face     = font.face and init[font.face] or 'ＭＳ ゴシック'
	font.rubyface = font.ruby and init[font.ruby]
	font.overflow = 1
	e:tag(font)

	-- show/hide
	local s = font.show
	if s and s ~= 'none' and s ~= 'cache' then
		e:tag{"scetween", mode="init", type="show"}
		e:tag{"scetween", mode="add",  type="show", param="alpha", ease="none", diff="0", time=(s), delay="0"}
		e:tag{"scetween", mode="init", type="hide"}
		e:tag{"scetween", mode="add",  type="hide", param="alpha", ease="none", diff="-255", time=(s), delay="0"}
	end

	-- indent
	local z  = getLangHelp("system")
	local id = font.indent
	if id and z[id] then
		e:tag{"indent", pair=(z[id]), nest="0", range="2"}
	else
		e:tag{"indent", pair="", nest="0", range="0"}	-- indent無効化
		e:tag{"wordparts", parts="!"}					-- 英単語判定無効化
	end

	-- prohibit
	local pr = tn(font.prohibit)
	if pr == 2 then e:tag{"prohibit", head=(z.prohibit_head_s or ""), foot=(z.prohibit_foot_s or "")}
	elseif pr then	e:tag{"prohibit", head=(z.prohibit_head   or ""), foot=(z.prohibit_foot   or "")}
	else			e:tag{"prohibit", head=" ", foot=" "} end
	e:tag{"/chgmsg"}
end
----------------------------------------
-- 
----------------------------------------
-- システム読み直し
function reloadSystemData()
	system_cachedelete()		-- system cache delete
	flg.textfont = nil			-- fontクリア
	set_uipath()				-- ui path再設定
	font_init()					-- font再設定 / tbl読み直し
	system_cache()				-- system cache
end
----------------------------------------
-- 
----------------------------------------
function loading_on()	if loading_icon then e:tag{"lyprop", id="zzlogo.load", visible="1"} e:tag{"lyprop", id="zzlogo.save", visible="0"} end end
function loading_off()	if loading_icon then e:tag{"lyprop", id="zzlogo.load", visible="0"} e:tag{"lyprop", id="zzlogo.save", visible="0"} end end
function saving_on()	if loading_icon then e:tag{"lyprop", id="zzlogo.load", visible="0"} e:tag{"lyprop", id="zzlogo.save", visible="1"} end end
function saving_off()	if loading_icon then e:tag{"lyprop", id="zzlogo.load", visible="0"} e:tag{"lyprop", id="zzlogo.save", visible="0"} end end
----------------------------------------
function loading_func(p)
	if loading_icon then
		local flag = p["0"] or 'off'
		local logo = p["1"] ~= "logo" and true
		if flag == 'on' then
			loading_on()
			if logo then lyc2{id="zzlogn", file=(init.black), alpha="128"} end
			flip()
		else
			loading_off()
			if logo then tag{"lydel", id="zzlogn"} end
			flip()
		end
	end
	wt()
end
----------------------------------------
function saving_func(p)
	if loading_icon then
		local flag = p["0"] or 'off'
		if flag == 'on' then saving_on()  lyc2{id="zzlogn", file=(init.black), alpha="128"}
		else				 saving_off() tag{"lydel", id="zzlogn"} end
		flip()
	end
	wt()
end
----------------------------------------
-- loadmask
function loadmask_func(p)
	local f = p["0"] or p.del
	local t = p.time
	if f then
		local v = scr.bgm
		if v then
			local tm = t or init.ui_fade
			local vl = v.vol or 1000
			tag{"sfade", gain=(vl), time=(tm)}	-- bgm復帰

			-- bgv復帰
			local b = scr.lvo
			if b and not flg.ui then
				for i, v in pairs(b) do
					local g = v.p.gain or 1000
					tag{"sefade", id=(v.id), gain=(g), time=(tm)}
				end
			end
		end
		uimask_off()
	else
		local tm = t or init.ui_fade
		tag{"sfade", gain="0", time=(tm)}	-- bgm

		-- bgv fadeout
		local b = scr.lvo
		if b and not flg.ui then
			for i, v in pairs(b) do
				tag{"sefade", id=(v.id), gain="0", time=(tm)}
			end
		end
		uimask_on()
	end
end
----------------------------------------
-- uimask
function uimask_func(p)
	local f = p["0"] or p.del
	if f then	uimask_off()
	else		uimask_on() end
end
function uimask_on()  e:tag{"lyc"  , id="zzamask", file=(init.black)} end
function uimask_off() e:tag{"lydel", id="zzamask"} end
----------------------------------------
--
----------------------------------------
-- check novel mode
function getNovel()
	return init.game_novel == "on"
end
----------------------------------------
-- get novel data
function getNovelData()
	return getNovel() and scr.novel
end
----------------------------------------
