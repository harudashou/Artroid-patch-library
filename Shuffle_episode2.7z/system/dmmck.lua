----------------------------------------
-- DMM Ck / windowsのみ呼ばれる
----------------------------------------
function dmmck_getuser()
	local r = {
		path = e:var("s.datapath"),
		save = e:var("s.savepath"),
		user = code_utf8(os.getenv("username") or "none")
	}
	return r
end
----------------------------------------
function init_dmmck()
	local path = "system/table/dmma.lub"
	local dmmf = sys.dmmcheck		-- 保存状態
	local r    = getOSMode()		-- 設定確認

	----------------------------------------
	-- NGID
	local ngfunc = function()
		local r = {}
		local px = "system/table/ngid.csv"
		if isFile(px) then
			local dx = parseCSV(px)
			for i, v in ipairs(dx) do
				if v[2] == "ng" then r[v[1]] = true end
			end
		end
		return r
	end

	----------------------------------------
	-- pack
	e:tag{"var", name="t.c", system="get_exe_parameter"}
	local c = e:var("t.c.com")
	if c == "pack" then

	----------------------------------------
	-- Steam
	elseif r.steam then

	----------------------------------------
	-- DMM Player
	elseif r.dmm then
		e:include("system/dmm.lub")		-- DMM Player Check

	----------------------------------------
	-- ソフト電池
	elseif r.softdc then
		local r   = true
		local crc = init.softdc_crc
		local exe = init.softdc_exe
		local dat = init.softdc_date

		-- 確認
		e:tag{"var", system="file_crc", name="t.crc", file=(exe)}
		local exc = e:var("t.crc")
		local dac = e:var("s.builddate")
		if exc == crc and dat == dac then r = nil end

		-- 無効
		if r then
			e:tag{"exit"}
		end

	----------------------------------------
	-- 認証データがすでにある
	elseif dmmf then
		local v = dmmck_getuser()

		-- PC Check
		if type(dmmf) ~= "table" or v.path ~= dmmf.path or v.user ~= dmmf.user or v.save ~= dmmf.save then
			sys.dmmcheck = nil
			init_dmmck()

		-- NG Check
		else
			local r = ngfunc()
			local s = dmmf.dmmf
			if r[s] then
				sys.dmmcheck = nil
				init_dmmck()
			end
		end

	----------------------------------------
	-- Windows版
	elseif isFile(path) then
		e:include(path)
		if mako then
			-- NGID
			ngid = ngfunc()

			-- ui
			flg.ui = {}
			csvbtn3("login", "500", csv.ui_login)
			setBtnStat('exit', 'c')
			estag("init")
			estag{"uitrans", 1000}
			estag{"allkeyon"}
			estag{"flip"}
			estag("stop")

		-- ここに来たら落とす
		else
			e:tag{"exit"}
		end

	-- ここに来たら落とす
	elseif not debug_flag then
		e:tag{"exit"}
	end
end
----------------------------------------
init_dmmck()
----------------------------------------
function dmmck_login()
--	ResetStack()
	local tx = flg.dmmcheck or ""
	tag_dialog({ title="キーをご入力ください", textfield="t.tx", textfieldsize="100", message=(tx) }, "dmmck_logincheck")
end
----------------------------------------
function dmmck_logincheck()
	local mx = 12
	local tx = string.lower(e:var("t.tx"))
	if tx == "" or tx:len() ~= mx or ngid[tx] then
		setBtnStat('exit', 'c')
		flip()
		tag_dialog({ title="エラー", message="不明なキーです" }, "dmmck_login")
	else
		local tbl = {}
		for i=1, mx do
			tbl[i] = (300 - tx:byte(i)) * 39
		end

		local f = nil
		for i, v in ipairs(mako) do
			local c = 0
			for i=1, mx do
				if tbl[i] == v[i] then c = c + 1 else break end
			end
			if c == mx then f = true break end
		end

		if f then
			local id = "500.log"
			ui_message((id), { 'login', text=(tx)})
			setBtnStat('exit', nil)
			flip()
			flg.dmmcheck = tx
		else
			tag_dialog({ title="エラー", message="不明なキーです" }, "dmmck_login")
		end
	end
end
----------------------------------------
function dmmck_exit()
	local dmmf = flg.dmmcheck
	if dmmf then
		mako = nil
		ngid = nil

		-- 保存
		local r = dmmck_getuser()
		r.dmmf = dmmf
		sys.dmmcheck = r
		ui_message("500.log")
		estag("init")
		estag{"syssave"}
		estag{"reset"}
		estag()
	else
		e:tag{"exit"}
	end
end
----------------------------------------
