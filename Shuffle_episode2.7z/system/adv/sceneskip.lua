----------------------------------------
-- シーンスキップ制御
----------------------------------------

sceneskip = {}

local gui = {
	--[[
	file = "",
	path = "",
	texts = {},
	icons = {},
	visible = false,
	--]]
}

sceneskip.flg = {
	--[[
	select = false, --sceneskip用のyesno選択肢を表示しているか
	skip = false, --exskipがシーンスキップか
	enter = false, --exskip終了時にシーンスキップ画面へ入るか
	uimask = false, --シーンスキップ画面から出たときにuimaskの解除が必要か
	--]]
}

local function reset()
	gui = {}
	sceneskip.flg = {}
end

local function getCurrentScenarioName()
	return scr.ip and scr.ip.file
end

--(AD)：全読フラグを取得
local function isAllReading(file)
	return file and gscr.aread and gscr.aread[file] and gscr.aread[file].all
end

--(AD)：現在のシナリオに全読フラグを立てる
local function setSceneAread()
	local file = getCurrentScenarioName()
	if file and gscr.aread and gscr.aread[file] then
		gscr.aread[file].all = true
	end
end

--(AD)：シーンスキップ（exskip）開始
function sceneskip_start()
	sceneskip.flg.skip = true
	goNextSelect()
end

--(AD)：シーンスキップで"No"を選択したときにADV画面を復帰する処理
function sceneskip_exit()
	--reset()
	sceneskip.flg.uimask = true
	set_backlog_next()		-- バックログ格納
	checkAread()			-- 既読
	quickjump(#log.stack, "exskip")
end

--(AD)：GUI表示
function sceneskip_show()
	--(AD)：なぜか連続で実行されるので、何度も表示しないようにする
	if gui.visible then return end
	gui.visible = true

	--(AD)：基本情報
	local base = getMWID("ssbg").."."				-- id base
	local path = game.path.ui
	local c = {}					-- 画像情報

	--(AD)：背景表示
	image_view({ file=gui.file, path=gui.path }, true)

	--(AD)：UI画像
	c = csv.mw.ssbg
	lyc2{ id=base.."0", file=(path..c.file)}

	--(AD)：アイコン表示
	local icons = {}
	local exclud = {} --(AD)：不要なキャラの削除
	for i, v in ipairs(split(init.sceneskip_exclud, ",")) do exclud[v] = true end
	for i, v in ipairs(gui.icons) do
		if not exclud[v] then
			table.insert(icons, v)
		end
	end
	local max = #icons
	c = csv.mw.ssicon
	local margin = tn(c.clip_a) / max --(AD)：アイコンの数が増えると隙間を狭くしていく
	local size = c.w + margin
	local x = (game.centerx - size/2) - (size * (max-1)/2) + margin/2 + c.x --(AD)：中央揃え
	local y = c.y
	for i, v in ipairs(icons) do
		local id = base.."icon."..i
		lyc2{id=id, file=(path..c.file.."icon_"..v)}
		tag{"lyprop", id=id, left=(x + size * (i-1)), top=y}
	end

	--(AD)：テキスト表示
	for i, text in ipairs(gui.texts) do
		local id = base.."text."..i
		set_textfont("sceneskip"..string.format("%02d", i), id)
		e:tag{"chgmsg", id=id, layered="1"}
		e:tag{"rp"}
		e:tag{"print", data=(text)}
		e:tag{"/chgmsg"}
	end
	cgdel_main({id=1, lv=5, maskid=1, time=0}) --(AD)：アイキャッチ動画の削除
	uimask_off()
end

--(AD)：GUI非表示
function sceneskip_hide()
	gui.visible = false

	local base = getMWID("ssbg")
	lydel2(base)

	--(AD)：テキスト削除
	base = base.."."				-- id base
	for i, text in ipairs(gui.texts) do
		local id = base.."text."..i
		e:tag{"chgmsg", id=id, layered="1"}
		e:tag{"rp"}
		e:tag{"/chgmsg"}
	end
	uimask_on()
end

--(AD)：シーンスキップタグをパスする。[select]タグを流用しているため必要
function sceneskip_pass()
	message("通知", "シーンスキップ画面をパスしました")

	-- 事後処理
	--exselback("selsave")	-- 前の選択肢に戻る、の情報をスタック / scr.select削除前に実行
	select_reset()			-- バッファクリア
	scr.ip.count = nil		-- カウンタリセット
	scr.flowposition = nil	-- フローチャート位置情報削除
	clickEnd(e, {not_mask_del=true})				-- click終了処理を通す
	ResetStack()			-- stackを空にする
	stack_eval()		-- 更新があったのでスタックしておく
	autocache()			-- 自動キャッシュ
	tag{"jump", file="system/script.asb", label="main"}
end

--(AD)：シーンスキップのタグを踏んだときの分岐
function sceneskip_init(p)
	local isOn = conf.sceneskip == 1
	local isRead = isAllReading(getCurrentScenarioName())

	--(AD)：シーンスキップの画面を表示するか分岐
	if isOn and isRead and not flg.exskip then
		--(AD)：シーンスキップ画面の表示
		reset()
		scr.select.sceneskip = {}
		sceneskip.flg.select = true

		--(AD)：パラメーター分解
		gui = {
			file = p.file,
			path = p.path,
			texts = { p.text1, p.text2 },
			icons = {},
		}
		for _, v in ipairs(split(p.icon, ",")) do
			table.insert(gui.icons, v)
		end
		scr.select.sceneskip.gui = gui

		--(AD)：シーンスキップ画面表示前に終端処理
		local time = init.sceneskip_uifade
		ResetStack()
		delImageStack()					-- cache開放
	
		-- 全音停止
		estag("init")
		estag{"allsound_stop", { time=(time) } }
		estag{"notification_clear"}		-- 通知消去
		estag{"adv_cls4"}				-- テキスト消去
	
		-- 共通消去
		estag{"reset_bg"}				-- quickjumpで復帰させるので消しておく
		estag{"uimask_on"}				-- 一応maskで隠す
		estag{"uitrans", time}

		--(AD)：yesno選択肢呼び出し
		estag{"select_start", { mode="yesno" }}
		estag()
	elseif flg.exskip and sceneskip.flg.skip then
		--(AD)：exskip中にシーンスキップタグに入った
		sceneskip.flg.enter = isOn and isRead --(AD)：シーンスキップ機能がオンで全読フラグが立っていたら"exskip_stop"でクイックジャンプしない
		estag("init")
		estag{"exskip_stop"}
		estag()
	else
		--(AD)：シーンスキップ画面を出さない場合は必ずクリック処理
		estag("init")
		estag{"sceneskip_pass"}
		estag()
	end
end

function sceneskip_restore()
	local s = scr.select and scr.select.sceneskip
	if s then
		gui = s.gui
		sceneskip.flg.select = s and true
	end
end

--(AD)：日付変更演出用にシーンスキップでuimuskを表示した状態にするタグ用
function sceneskip_uimask_on(p)
	local time = p and p.time or init.sceneskip_uifade
	sceneskip.flg.uimask = true
	estag("init")
	estag{"uimask_on"}
	estag{"uitrans", time}
	estag()
end

--(AD)：シーンスキップ直後のクリック待ちのみuimaskを解除する
function sceneskip_uimask_off(p)
	if sceneskip.flg.uimask then
		local time = p and p.time or init.sceneskip_uifade
		sceneskip.flg.uimask = false
		estag("init")
		estag{"uimask_off"}
		estag{"uitrans", time}
		estag()
	end
end

--(AD)：タグ用
function tags.scenearead(e, p) setSceneAread(p) return 1 end
function tags.uimaskon(e, p) sceneskip_uimask_on(p) return 1 end
function tags.uimaskoff(e, p) sceneskip_uimask_off(p) return 1 end
