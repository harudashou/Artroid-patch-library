----------------------------------------
-- スクリプト管理
----------------------------------------
-- スクリプトを読み込む / reset
function readScriptStart(file, label, p)
	flg = nil
	scr = nil
	vartable_init()
	allkeyon()

	-- 初期値を埋め込む
	if p then
		for k, v in pairs(p) do scr[k] = v end
	end

	readScript(file, label)
	adv_reset()
	reset_backlog()
	checkAread()		-- ファイル先頭の既読処理
	autocache(true)		-- 自動キャッシュ
	e:tag{"jump", file="system/script.asb", label="main"}
end
----------------------------------------
-- スクリプトを読み込む
function readScript(file, label)
	local r = readScriptFile(file)
	if not ast then
		return
	elseif ast and not r and scr.ip and scr.ip.file then
		file = scr.ip.file
	end

	-- 保存しておく
	scr.ip = {
		file  = file,	-- 実行中のファイル
		block = 1,		-- 実行中のブロック
		count = 1,		-- 実行中の行
	}

	-- labelがあればラベル行をセット
	local l = label and ast.label and ast.label[label]
	if l then
		scr.ip.block = l.block
		scr.ip.count = l.label
	end
	scr.areadflag = "reset"		-- 既読リセット

	message("通知", scr.ip.file, "(", label, ")", "を呼び出します")

	-- 初期化
	adv_init()
--	pushGSS()
end
----------------------------------------
-- スクリプトファイルの読み込みだけを行う／ast[]に格納される
function readScriptFile(file, flag)
	ast = nil
	local ret = nil
	local fo  = init.script_format
	local fl  = file
	if tn(fl) and fo then fl = string.format(fo, fl) end
	local path = init.script_path..fl..init.script_ext
	if e:isFileExists(path) then
		if not flag then delImageStack() end	-- cache delete
		e:include(path)							-- script include
		ret = true
	else
--		message("エラー", file, "が見つかりませんでした")
		tag_dialog({ title="エラー", message=(file.."が見つかりませんでした") }, "stop")
	end
	return ret
end
----------------------------------------
-- goto処理
function gotoScript(p)
	local file	= p.file or scr.ip.file
	local label	= p.label
	--sceneskip.setSceneAread() --(AD)：ファイルジャンプの際にシナリオ全読のフラグを立てる
	readScript(file, label)
	if ast then
		checkAread()		-- ファイル先頭の既読処理
		if game.trueos == "wasm" then
			flg.wasmcache = p.file
			e:tag{"jump", file="system/script.asb", label="wasmcache"}
		else
			autocache(true)		-- 自動キャッシュ
			e:tag{"jump", file="system/script.asb", label="main"}
		end
--	else
--		tag{"var", name="t.error", data=(file.."は無効なファイルです")}
--		tag{"call", file="system/script.asb", label="error"}
	end
end
----------------------------------------
-- jumpex
function tags.jumpex(e, p)
	local o = game.os
	local r = nil
	if (p.mode == "not" and o ~= p.os) or (p.mode == "not" and o ~= p.os) then r = true end

	message("分岐", o, p.mode, p.os, r)

	if r then
		gotoScript{ file=(scr.ip.file), label=(p.label) }
	end
end
----------------------------------------
-- XMJP
function tags.XMJP(e, p)
	if type(extra) == "string" then
		gotoScript{ file=(scr.ip.file), label=(p.label) }
	end
end
----------------------------------------
-- uiからスクリプトを呼ぶ
function callscript(mode, file, label)
	readScript(file, label)
	if ast then
		if mode == "adv" then
			adv_reset()
			reset_backlog()
			init_adv_btn()
		end
		tag{"jump", file="system/script.asb", label="main"}
	end
end
----------------------------------------
-- 
----------------------------------------
-- load解析
function scriptLoad(ip, f)
	readScriptFile(ip.file)
--[[
	----------------------------------------
	-- crc比較
	local bl = ip.block
	local sa = ip.save
	local bc = ast[bl]
	if bl == 0 or scr.autosave then return		-- logなし / autosaveは何もしない
	elseif sa.txno == bc.txno then
		-- 完全一致
		if sa.crc == bc.crc then
			return
		-- text一致 / 画像は読み直す
		else
			return bl
		end
	end

	-- text table比較
	local st = sa.text				-- save text
	local rt = getTextBlockText()	-- 現在位置text
	local ln = get_language(true)
	local sv = st.vo and st.vo[1] and st.vo[1].file
	local rv = rt.vo and rt.vo[1] and rt.vo[1].file
	if sv and sv == rv then return end		-- ボイス一致
	if st[ln] == rt[ln] then return end		-- テキスト完全一致

dump(ip)
	----------------------------------------
	-- 差異確認

]]
end
----------------------------------------
-- 
----------------------------------------
-- メインループ
function scriptMainloop()
	local b = scr.ip.block			-- block
	local c = scr.ip.count or 1		-- block count
	local v = ast[b] and ast[b][c]

	-- cond処理を無視するタグ
	local ng = { select=1 }

	-- exskipで実行するタグ
	local st = init.exskip or {}
	local nm = v and v[1]
	local tagst = {
		fg = function(p) exskip_fg(p) end,
		bg = function(p)
			if p.set then evset(p)
			else		  bgset(p) end

			--(AD)：お気に入りボイス用の処理
			local no = (p.id or 0) + 1
			local id = getImageID('bg', p)
			scr.img.bg[no] = { path=(p.path), file=(p.file), id=(p.id), lv=(p.lv), idx=(id), set=(p.set) }
			scr.face = nil
		end,
		bgm = function(p)
			if p.file then bgm_unlock(p) end
		end,
	}

	-- 終端到達
	if not v then
		exreturn()

	-- テキストブロック
	elseif not nm and v.text then

	-- tag実行
	elseif tags[nm] then
		if ng[nm] or not v.cond or cond(v.cond) == 1 then
			storeQJumpStack(nm, v)

			-- exskip
			if flg.exskip then
				if st[nm] then			tags[nm](e, v)		-- exskip中も実行する
				elseif tagst[nm] then	tagst[nm](v)		-- exskip中は部分実行する
				end
			else
				tags[nm](e, v)
			end
		end
	else
		e:tag(v)
	end
end
----------------------------------------
-- メインループ／text表示
function scriptMainloopText()
--	chgmsg_adv()
--	message_adv(scr.text)
--	scr.text = nil
end
----------------------------------------
-- メインループ／加算
function scriptMainAdd()
	local b = scr.ip.block			-- block
	local c = scr.ip.count or 1		-- block count
	local m = table.maxn(ast[b])
	c = c + 1
	if c <= m then
		scr.ip.count = c
	else
		stack_eval()		-- 更新があったのでスタックしておく
		set_backlog_next()	-- バックログ格納
		checkAread()		-- 既読
		scr.ip.count = nil	-- カウンタリセット

		-- クリック待ち
		e:tag{"jump", file="system/script.asb", label="click"}
	end
end
----------------------------------------
-- クリック処理
----------------------------------------
-- クリック待ち開始前の処理
function clickPrepare(e, p)
	setCaption()			-- debug情報

	-- 画像処理
	if scr.img.buff then image_loop() end

	-- exskip
	if flg.exskip then
		-- debug
		if debug_flag and flg.dbskip then
			debugMenuGoNextSkipStop()

		-- 未読停止
		elseif not scr.areadflag and conf.messkip == 0 then
			exskip_stop("cache")
		end
		e:tag{"wait", time="0", input="0"}
	end
end
----------------------------------------
-- クリック待ち開始
function clickStart(e, p)
	if not flg.exskip then
		delay_check()	-- delay
	end
	flg.click = true	-- click flag

	sceneskip_uimask_off()
end
----------------------------------------
-- delay skip
function delayStop()
	local key = flg.delaykey
	if key then
		delay_skipstop()		-- delayskip終了
		flip()

		-- クリック以外のキー
		if key[2] ~= "CLICK" then
			flg.exclick = key[1]

		-- ボタンがクリックされた
		elseif key[1] == 1 and key[3] then
			flg.btnclick = 1
			flg.exclick = 1
		end
		flg.delaykey = nil
	end
end
----------------------------------------
-- クリック直前
function clickAutomode()
	-- automode
	if flg.automode then
		if conf.autostop == 1 then
			eqtag{"automode", syncse=(sesys_getvoauto())}
		end
--		eqwait{ scenario="1" }

	-- skip speed
	elseif flg.skipmode then
		local s = conf.skipspd
		if s then
			local tm = s * 2
			if tm > 0 then
				e:tag{"wait", time=(tm), input="0"}
			end
		end

	-- glyph
	elseif not getSkip() then
		local s = init.anime_glyphstart
		if _G[s] then _G[s]() end
	end
end
----------------------------------------
-- クリック直後の処理
function clickEnd(e, p)
	flg.click = nil
	flg.automodeclick = nil
	flg.cgtweendel = nil	-- CG tween停止の管理フラグ
	scr.ip.textcount = nil	-- text counter
	scr.vo = nil			-- voice del
	mw_facedel()			-- face del
	sm_text()				-- sm del
	adv_clsclick()			-- cls
--	chgmsg_adv("close")		-- /adv
--	delay_skipstop()		-- delayskip終了
	flg.act = nil			-- action
	flg.delaykey = nil
	if p and not p.not_mask_del then
		cgdel({id=1, lv=5, maskid=1, time=0}) --(AD)：アイキャッチ動画の削除
	end
	flip()

	-- クリックで音声停止
	if flg.automode then e:tag{"automode", syncse=""}
	elseif conf.voiceskip == 1 then sesys_stop("voice") end
	scr.voice.stack = {}	-- voiceバッファクリア

	-- 既読
	setAread()
	scr.ip.block = scr.ip.block + 1		-- ブロック加算
	checkAread()

	-- automode
--	if flg.automode then e:tag{"automode", syncse=""} end
end
----------------------------------------
-- 既読処理
----------------------------------------
-- 現在の既読情報を確認
function checkAread()
	local ar = getAread()	-- 既読
	if ar ~= scr.areadflag then
		-- 既読マーク
		local a = ar and 255 or 0
		local id = getMWID("read")
		if id then e:tag{"lyprop", id=(id), visible=(a)} end
--		flip()
	end
	scr.areadflag = ar
end
----------------------------------------
-- 現在の既読情報を取得
function getAread()
	local ret = nil
	local p = scr.ip
	if p and gscr.aread[p.file] then
		local no = p.block
		for i, v in ipairs(gscr.aread[p.file]) do
			if v[1] <= no and no <= v[2] then ret = true break end
		end
	end
	return ret
end
----------------------------------------
-- 既読セット
function setAread()
	local p = scr.ip
	if p then
		local file = p.file
		local no   = p.block
		local flag = true
		if not gscr.aread[file] then gscr.aread[file] = {{ no, no }} flag = nil end
		for i, p in ipairs(gscr.aread[file]) do
			local n = p[2]

			-- 既に範囲内なら何もしない
			if p[1] <= no and no <= n then
				flag = nil
				break

			-- 範囲の１個次なら保存する
			elseif n + 1 == no then
				gscr.aread[file][i][2] = no
				flag = nil
				break
			end
		end

		-- 番号が飛んだらテーブルを追加する
		if flag then
			table.insert(gscr.aread[file], { no, no })
		end
	end
end
----------------------------------------
-- シーン処理
----------------------------------------
-- tweet
function ex_tweetset(p)
	local mode = tn(p.mode)
	if mode == 1 then
		message("通知", "ツイート禁止")
		scr.ero = true
	else
		message("通知", "ツイート許可")
		scr.ero = nil
	end
end
----------------------------------------
-- 開始
function sceneStart()
	message("通知", "シーン開始")

	-- Hシーンフラグ
--	scr.ero = true

	-- MWをシンプルにする
--	if conf.mw_simple == 1 then
--		setMWImage("bg2")
--		mw_alpha()
--	end
end
----------------------------------------
-- 終了
function sceneEnd(p)
	-- Hシーンフラグ
--	scr.ero = nil

	-- MWを戻す
--	setMWImage("bg")
--	mw_alpha()

	-- タイトル画面に戻す
	if getExtra() then
		scr.fo = nil
		notification_clear()	-- 通知を消す
		eqtag{"jump", file="system/ui.asb", label="exscene_jumpend"}

	-- 登録
	else
		local set = p["0"] or p.file
		if set then
			message("通知", set, "をシーン登録しました")
			gscr.scene[set] = true
			asyssave()	-- save
--		else
--			message("通知", "ツイート許可")
		end
	end
	return 1
end
----------------------------------------
