----------------------------------------
-- フローチャート
----------------------------------------
--	flowchart_text = true
----------------------------------------
-- 開放確認
function flow_check(flag)
	local f = tn(get_eval("g.e01")) == 1
	local r = flag and f or f and not scr.firsthalf
	return r
end
----------------------------------------
-- 
function flow_init()
--	message("通知", "フローチャートを開きました")
--	se_ok()

	-- ボタンワーク初期化
	sys.flow = { buff=0 }
	flg.flow = { flag={} }
	flg.flow.ga = tn(get_eval("g.alpha"))	-- αルート開放
	flg.flow.gb = tn(get_eval("g.beta"))	-- βルート開放
	flg.flow.gg = tn(get_eval("g.gamma"))	-- γルート開放
	flg.flow.go = tn(get_eval("g.omega"))	-- Ωルート開放
	flg.flow.gs = tn(get_eval("g.sigma"))	-- Σルート開放
	flg.flow.gd = tn(get_eval("g.delta"))	-- Δルート開放
--	flg.flow.gf = tn(get_eval("g.e01"))		-- 1stend
	flg.flow.ek = tn(get_eval("g.clear_b15"))	-- えみかな
	flg.flow.y  = 0

--	flg.flow.ga = 1
--	flg.flow.gb = 1
--	flg.flow.gg = 1
--	flg.flow.go = 1

	local f = flg.flow

	message("通知", "フローチャートを開きました a:", f.ga, "b:", f.gb, "g:", f.gg, "o:", f.go)

	-- スクロール範囲の最大値を求める
	local max = 430
		if f.ek == 1 then max = 2100		-- えみかな開放
	elseif f.gd == 1 then max = 2010		-- Δ開放
	elseif f.gs == 1 then max = 2010		-- Σ開放
	elseif f.go == 1 then max = 1840		-- Ω開放
	elseif f.gg == 1 then max = 1540		-- γ開放
	elseif f.gb == 1 then max = 1080		-- β開放
	elseif f.ga == 1 then max = 780 end		-- α開放
	if getTrial() and max > 780 then max = 780 end
	flg.flow.max = max

	-- 現在位置
	local fl = scr.ip and scr.ip.file
	if fl then
		local tb = {
			_00_prologue	= "fa00",
			_03_b_05_00		= "fb05a",
			_03_b_05_01_h_re= "fb05a",
			_03_b_05_02		= "fb05b",
			_06_b_12		= "fb12a",
			_06_b_12_02		= "fb12b",
			_06_b_15_e24	= "fb15a",
			_06_b_15_e24_2	= "fb15b",
			_07_emiend_re	= "fb91",
			_07_kanaend_re	= "fb92",
		}
		if tb["_"..fl] then
			fl = tb["_"..fl]
		else
			local ax = explode("_", fl)
			fl = "f"
			if ax[2] then fl = fl..ax[2] end
			if ax[3] then fl = fl..ax[3] end
		end
	end
	local m = scr.flowposition or fl
	local c = csv.ui_flow
	local y = 0
	local f = nil
	if m and c[m] then
		f = c[m]
		y = f.y - 20
		if y < 0 then y = 0 elseif y > max then y = max end
	end
	flg.flow.now = m

	-- 画面を作る
	flow_readcsv()
	if y > 0 then flowmap(y) end
	if f then
		flow_iconcolor(m, 4)
		flowicon("500."..f.id, f.w)
	end
	uiopenanime("flow")
end
----------------------------------------
-- 状態クリア
function flow_reset(p)
	delbtn("flow")		-- 削除
	flg.flow = nil		-- ボタン用ワークを削除
	sys.flow = nil
end
----------------------------------------
-- flow画面から抜ける
function flow_close()
	message("通知", "フローチャートを閉じました")

	se_cancel()
--	uicloseanime("flow")
	flow_reset(e, {})

	-- タイトル画面以外
	if not getTitle() then uitrans() end
end
----------------------------------------
-- 
----------------------------------------
-- 画面作成
function flow_readcsv()

	-- ボタン配置
	csvbtn3("flow", "500", csv.ui_flow)
	local id = "500.0"
	local wd = game.width
	local he = game.height
	lyc2{ id=(id..".0"), width=(wd), height=(he), color="000000"}
	lyc2{ id=(id..".1"), width="60", height=(he), color="404f80", x=(wd-60)}

	-- drag
	lyc2{ id=(id..".drag"), width=(wd-60), height=(he), color="000000", draggable="1", dragarea="0,-720,0,720"}
	lyevent{ id=(id..".drag"), dragin="flow_draginit", drag="flow_drag", dragout="flow_dragout"}

	-- ルートツリーを非表示してしまう
	local f = flg.flow
	local ga = f.ga == 0
	local gb = f.gb == 0
	local gg = f.gg == 0
	local go = f.go == 0
	local gs = f.gs == 0
	local gd = f.gd == 0
	local ek = f.ek == 0
	local tr = getTrial()

	-- text and line
	local path = game.path.ui.."flow/"
	for bt, v in pairs(flowtbl) do
		local n = v.gscr
		local o = v.open
		local c = tn(gscr.vari[n])
		local b = checkBtnExist(bt) and getBtnInfo(bt) or {}
		local id = b.idx
		local lf = nil

		-- 開放確認
		if o then
			if o.b15 and ek
			or o.t and tr
			or o.a and ga
			or o.b and gb
			or o.g and gg
			or o.s and gs
			or o.d and gd
			or o.o and go then
				tag{"lyprop", id=(id), visible="0"}
			end
		end

		-- text / debug用
if flowchart_text and id then
		local wd = b.w
		local ix = id..".20"
		set_textfont("flow", ix)
		tag{"chgmsg", id=(ix), layered="1"}
		tag{"font", width=(wd)}
		tag{"rp"}
		tag{"print", data=(v.text)}
--		tag{"/font"}
		tag{"/chgmsg"}
end

		-- 開放
		if id and (not n or n == 'lineopen' or c == 1) then
			tag{"lyprop", id=(b.idx..".0"), clip=(b.clip_d)}

			-- flag
			local fl = v.file
			if fl then flg.flow.flag[bt] = true end
			lf = true

		-- 禁止
		elseif checkBtnExist(bt) then
			if bt == "fb91" or bt == "fb92" then
				flg.flow.flag[bt] = true
			else
				setBtnStat(bt, 'c')
			end
		end

		-- line
		local ln = v.line
		if id and ln then
			local iz = id..".-1"
			if c == 1 or n == "lineopen" then ln = ln.."_a" end
			lyc2{ id=(iz), file=(path..ln), x=(v.lx), y=(v.ly), clip=(v.clip)}
		end
	end

	-- タイトル画面
	if getTitle() then setBtnStat('bt_title', 'c') end
end
----------------------------------------
-- flowchart icon
function flowicon(id, wx)
	local t = csv.mw.glyphflow
	local w = t.w
	local x = t.x + wx
	local y = t.y
	local z = ","..w..","..t.h

	local path = game.path.ui..t.file
	local id = id.."."..t.id
	local mx = t.loop
	local tm = t.time
	local hm = t.homing
	e:tag{"anime",		id=(id), mode="init", file=(path), clip=("0,0"..z)}
	for i=1, mx do
		local time = i * tm
		if i == mx then time = time + hm end
		e:tag{"anime",	id=(id), mode="add",  file=(path), clip=((i * w)..",0"..z), time=(time)}
	end
	e:tag{"anime",		id=(id), mode="end",  time=(mx * tm + hm)}
	e:tag{"lyprop",		id=(id), left=(x), top=(y)}
end
----------------------------------------
-- drag
----------------------------------------
-- 
function flow_draginit(e, p)
	local bt = btn.cursor
	if not bt and not flg.dlg then flg.flow.drag = flg.flow.y end
end
----------------------------------------
-- 
function flow_drag(e, p)
	local dr = flg.flow.drag
	if dr then
		e:tag{"var", name="t.ly", system="get_layer_info", id="500.0.drag"}
		local dy = tn(e:var("t.ly.top"))
		local y  = dr - dy
		local m  = flg.flow.max
		if y < 0 then y = 0 elseif y > m then y = m end
		flowmap(y)
		flip()
	end
end
----------------------------------------
-- 
function flow_dragout(e, p)
	local id = "500.0"
	tag{"lyprop", id=(id..".drag"), top="0"}
	flip()
	flg.flow.drag = nil
end
----------------------------------------
-- スライダー
----------------------------------------
function flow_slider(e, p)
	local z = tn(p.p)
	local o = tn(p.old)
	if z ~= o then
		local m = flg.flow.max
		local y = repercent(z, m)
		flowmap(y)
		flip()
	end
end
----------------------------------------
-- 位置を変える
function flowmap(y)
	tag{"lyprop", id="500.gr", top=(-y)}
	flg.flow.y = y

	-- slider
	local v = getBtnInfo("slider")
	local f = flg.flow
	local m = f.max
	local a = percent(y, m)
	local h = repercent(a, v.h - v.p2)

	local id = v.idx..".10"
	tag{"lyprop", id=(id), top=(h)}
end
----------------------------------------
-- 動作
----------------------------------------
-- クリック
function flow_click(e, p)
	local bt = p.btn or p.key or btn.cursor
	if bt then
		local v  = getBtnInfo(bt)
		local p1 = v.p1
		local p2 = tn(v.p2)
		local sw = {
			scroll = function() flow_scroll(p2) end,

			bt_title	= function() adv_title() end,
			bt_exit		= function() adv_exit() end,
			bt_end		= function() adv_exit() end,
		}
		if p1 and sw[p1] then sw[p1]()
		elseif sw[bt] then sw[bt]()
		elseif flowtbl[bt] then
			local s = flowtbl[bt]
			local fl = s.file
			if fl and flg.flow.flag[bt] then
				se_ok()
				flg.flow.file  = s.file
				flg.flow.label = s.label
				dialog("flow")
			end
		end
	end
end
----------------------------------------
-- 
function flow_scroll(add)
	local f = flg.flow
	local y = f.y + add
	local m = f.max
	if y < 0 then y = 0 elseif y > m then y = m end

	flowmap(y)
	flip()
end
----------------------------------------
-- 
function flow_iconcolor(nm, num)
	local b = getBtnInfo(nm)
	if type(num) == "number" then
		local cl = b.cx..","..(b.ch*num)..","..b.cw..","..b.ch
		tag{"lyprop", id=(b.idx..".0"), clip=(cl)}
	else
		tag{"lyprop", id=(b.idx..".0"), clip=(b[num])}
	end
end
----------------------------------------
-- 
function flow_over(e, p)
	local bt = p.name
	local m  = flg.flow.now
	if bt and m and m == bt then
		flow_iconcolor(bt, 5)
	end
end
----------------------------------------
function flow_out(e, p)
	local bt = p.name
	if bt then
		local f = flg.flow
		local m = f.now

		-- 赤:現在位置
		if m and m == bt then
			flow_iconcolor(bt, 4)

		-- えみかなend
		elseif bt == "fb91" or bt == "fb92" then
			local v = flowtbl[bt]
			local n = v.gscr
			local c = tn(gscr.vari[n])
			if c == 1 then flow_iconcolor(bt, "clip_d") end

		-- その他
		elseif bt and f.flag[bt] then
			flow_iconcolor(bt, "clip_d")
		end
	end
end
----------------------------------------
-- 
----------------------------------------
-- 該当スクリプト呼び出し
function flow_script()
	local s = flg.flow
	if s.file then
		adv_cls4()
		mwline_reset()			-- lane

		-- 選択肢
		if scr.select then
			select_reset()		-- reset
			set_message_speed()	-- mspeed復帰
		end

		-- 全音停止
		estag("init")
		estag{"allsound_stop", { time=(time) } }
		estag{"flow_reset"}
--		estag{"uimask_on"}
		estag{"reset_bg"}
		estag{"uitrans", time}
		estag{"flow_script2", s}
		estag()
	end
end
----------------------------------------
function flow_script2(p)
	ResetStack()
	scr.advinit = nil
	readScriptStart( p.file, p.lael )
end
----------------------------------------
