----------------------------------------
-- 画像ダイアログ
----------------------------------------
function dialog(name)
	fn.push("dlg", {
		{ dialog_main, name },
		{ dialog_exit, name },
	})
end
----------------------------------------
-- dialogを抜けたあとに実行する
function dialog_exit(name)
	local r = fn.get()
	if r == 1 then
		local sw = {
			qsave = function() sv.quicksave() end,	-- qsave
			qload = function() sv.quickload() end,	-- qload
			save  = function() sv.saveclick() end,	-- save
			save2 = function() sv.saveclick() end,	-- save上書き
			load  = function() sv.loadclick() end,	-- load
			favo  = function() favoclick() end,		-- お気に入りボイス
			favo2 = function() favoclick() end,		-- お気に入りボイス上書き
			fdel  = function() favodelete() end,	-- お気に入りボイス削除

			reset = function() config_resetview() end,	-- config reset
			title = function() sv.go_title() end,	-- title
			exit  = function() sv.go_exit() end,	-- game exit
			scene = function() sv.go_title() end,	-- scene
			jump  = function() goBacklogJumpTo() end,	-- backlog jump

			back  = function() goBackSelect() end,	-- 前の選択肢に戻る
			next  = function() goNextSelect() end,	-- 次の選択肢に進む

			flow  = function() flow_script() end,	-- フローチャート確認
			web   = function() goWebAccess() end,	-- ブラウザを開く確認

			del   = function() sv.delete() end,		-- save data削除
			sus   = function() sv.suspend() end,	-- suspend

			tweet = function() ex_tweet() end,		-- tweet
			oksus = function() load_suspendcheck2() end,
			update = function() updater.start(true) end,
		}
		if sw[name] then
			message("通知", name, "を呼び出します")
			sw[name]()
		end
	else
--		reload_ui()
		mouse_reset()
	end
end
----------------------------------------
-- dialog / 新ルーチン
function dialog_main(name)
	local check = nil

	local bt = btn.cursor
	if bt then btn_nonactive(bt) end

	-- onになっていたらダイアログを表示せずに抜ける
	local dlg = get_dlgparam(name)
	if dlg == 1 then
--		se_ok()
		message("通知", "dialogで確認をしない設定です", name)
		return 1	-- yesの戻り値
	end

	message("通知", "dialogを開きました", name)

	-- ドラッグ禁止
	if flg.ui then sliderdrag_stat(0) end

	-- 初期化
	sys.dlg = { dummy=dlg }
	flg.dlg = { name=name }
	if btn and btn.name then
		flg.dlg.ui  = btn.name
		flg.dlg.glp = btn.group
		flg.dlg.btn = bt
	end

	-- 音声を停止する
	if not flg.ui then sesys_stop("pause") end

	-- sys voice
	local s = csv.sysse.sysvo
	if name and s[name] then sysvo(name) end

	-- チェックボックスは必ずoff
--	conf.dummy = 0

	-- ボタン描画
	csvbtn3("dlg", "600", csv.ui_yesno)	-- dialog
	local t = btn.dlg.p.bg
--	e:tag{"lyprop", id="600", anchorx=(math.floor(t.w/2 + t.x)), anchory=(math.floor(t.h/2 + t.y))}
--	e:tag{"lyprop", id="600.1", anchorx=(game.centerx), anchory=(game.centery)}
--	lyc2{ id="600.0", file=(init.black), alpha="128"}
--	lyc2{ id="600.0", width=(game.width), height=(game.height), color="F47AAA", alpha="128"}

	-- text
	yesno_text(name)

	-- okボタン処理
	local n3 = name:sub(1, 3)
	if n3 == "ex0" then		-- name == "ex01" or name == "ex02"
		setBtnStat('bt_yes', 'c')
		setBtnStat('bt_no', 'c')
		setBtnStat('bt_check', 'd')
		e:tag{"lyprop", id="600.1.bt", visible="0"}
		e:tag{"lyprop", id=(getBtnID('base')), clip="0,240,1280,236"}

	-- defaultは意味が無いのでcheckboxなし
--	elseif name == "reset" then
--		setBtnStat('bt_ok', 'c')
--		setBtnStat('bt_check', 'd')
--		e:tag{"lyprop", id=(getBtnID('bt_check')), visible="0"}
--	else
--		setBtnStat('bt_ok', 'c')
--		e:tag{"lyprop", id=(getBtnID('bt_ok')), visible="0"}
	end

	-- exit
--	if name ~= "exit" and not game.ps then
--		e:tag{"lyprop", id=(getBtnID('bt_sus')), visible="0"}
--	end

	-- 表示アニメ
	setonpush_ui()
	uiopenanime("dialog")
--	systween2{ id="600.1", y="-50,0", time=(init.ui_fade)}
--	uitrans()
--	tag{"call", file="system/ui.asb", label="dialog"}
end
----------------------------------------
-- yesをアクティブにする
function yesno_active()
	local time = init.ui_fade
	local id = "600.dl"
	tag{"lyprop", id=(id), visible="1"}
	tween{ id=(id), alpha="0,255", time=(time)}
	flip()
	if game.os == "windows" and conf.mouse == 1 then
		mouse_autocursor("bt_yes", time)
	else
		eqwait(time)
	end
	eqtag{"lytweendel", id=(id)}
end
----------------------------------------
-- dialog checkbox
function yesno_checkbox(e, p)
	btn_change()
end
----------------------------------------
-- dialog click
function yesno_click(e, p)
	local ret = 0
	local bt = btn.cursor
	if not bt then

	elseif bt == "bt_check" then
		yesno_checkbox(e, p)
	else
		if bt == "bt_yes" then
			se_yes()
			local nm = flg.dlg.name
			local tb = { exit=1, load=1, qload=1, favo=1, favo2=1, update=1 }
			if not tb[nm] then sysvo("dlgyes") end

			-- 状態保存
			local a = sys.dlg.dummy
			local n = flg.dlg.name
			set_dlgparam(n, a)
			if n == "reset" and a == 1 then sys.dlgreset = true end	-- config reset
			asyssave()
			ret = 1

		elseif bt == "bt_no" then
			se_no()
			sysvo("dlgno")
			flg.dlg.cancel = true

		elseif bt == "bt_ok" then
			se_ok()

		end
		fn.set(ret)
		yesno_exit()
	end
end
----------------------------------------
-- dialog escape
function yesno_esc(e, p)
	se_cancel()
	sysvo("dlgno")
	flg.dlg.cancel = true
--	if flg.dlg.name == 'qsave' then qsaveend(true) end
	fn.set(0)
	yesno_exit()
end
----------------------------------------
-- dialogを抜ける
function yesno_exit()
	ReturnStack()	-- 空のスタックを削除
--	message("通知", "dialogを閉じました")

	-- 画面を閉じる
--	tag{"var", name="t.lua", data="dialog_return"}
--	tag{"jump", file="system/ui.asb", label="return_ui"}
	uicloseanime("dialog")
end
----------------------------------------
-- dialogを抜ける
function dialog_return()
	local dlgp = flg.dlg
	local name = dlgp.name
	yesno_text()				-- 文字消去
	delbtn('dlg')				-- ui消去
	e:tag{"lydel", id="600"}
	btn.name	= flg.dlg.ui	-- 戻す
	btn.group	= flg.dlg.glp
	btn.cursor	= flg.dlg.btn
	flg.dlg = nil
	sys.dlg = nil
	delonpush_ui()

	-- checkbox check
	if name == "load" or name == "qload" then
		if get_dlgparam(name) == 1 then
			temp_dialog = name
		end
	end

--	adv_btnreset()

	-- ui
	if flg.ui then
		sliderdrag_stat(1)		-- ドラッグ許可
		setonpush_ui()
		if game.cs and dlgp.cancel and dlgp.btn and dlgp.ui ~= "adv" then
			btn_active2(dlgp.btn)
		end

	-- 選択肢
	elseif scr.select then
		sv.delpoint()
		sesys_resume()			-- se再開
		setonpush_ui()
	else
		sv.delpoint()
		sesys_resume()			-- se再開
		autoskip_init()
	end

	-- 戻る
	tag{"return"}
	tag{"jump", file="system/ui.asb", label="return"}
end
----------------------------------------
-- 文字
function yesno_text(name)

	-- csvから読み込む
	local v  = getLangHelp("dlgmes")
	if v then
		local id = "600.dl.text"
		if name then
			local tx = v[name] or ""
			ui_message(id, { "dialog", text=(tx) })
		else
			ui_message(id)
		end

	-- iptで処理
	elseif name then
		ipt = nil
		local path = game.path.ui.."mw/dialog.ipt"
		e:include(path)
		if not ipt then
			error_message("座標ファイルが見つかりませんでした")
		end
		tag{"lyprop", id=(getBtnID('message')), clip=(ipt[name])}
	end
end
----------------------------------------
